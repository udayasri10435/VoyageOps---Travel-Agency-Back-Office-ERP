import { Booking, CorporateAccount, Itinerary, Supplier, CommissionRecord } from '../types';

export const initialSuppliers: Supplier[] = [
  {
    id: 'sup-emirates',
    code: 'EK',
    name: 'Emirates Airline',
    category: 'airline',
    contactName: 'Tariq Al-Maktoum',
    contactEmail: 'agency.support@emirates.com',
    contactPhone: '+971 4 214 4444',
    contractType: 'gds_amadeus',
    defaultCommissionRate: 5.5,
    paymentTerms: 'net_15',
    creditLimit: 150000,
    balancePayable: 24500,
    rating: 4.9,
    activeContractsCount: 3,
    gdsOfficeId: 'DXB1A0982',
    notes: 'Premium partner. Tier 1 incentive override at $500k annual segment volume.'
  },
  {
    id: 'sup-singapore',
    code: 'SQ',
    name: 'Singapore Airlines',
    category: 'airline',
    contactName: 'Chloe Tan',
    contactEmail: 'trade_desk@singaporeair.com.sg',
    contactPhone: '+65 6223 8888',
    contractType: 'gds_sabre',
    defaultCommissionRate: 6.0,
    paymentTerms: 'net_15',
    creditLimit: 120000,
    balancePayable: 18200,
    rating: 4.9,
    activeContractsCount: 4,
    gdsOfficeId: 'SIN1S3820',
    notes: 'Corporate private fare filing for TechCorp and Apex accounts.'
  },
  {
    id: 'sup-lufthansa',
    code: 'LH',
    name: 'Lufthansa Group (LH/LX/OS)',
    category: 'airline',
    contactName: 'Markus Weber',
    contactEmail: 'b2b.frankfurt@lufthansa.com',
    contactPhone: '+49 69 86 799 799',
    contractType: 'gds_amadeus',
    defaultCommissionRate: 4.5,
    paymentTerms: 'net_30',
    creditLimit: 100000,
    balancePayable: 9400,
    rating: 4.6,
    activeContractsCount: 2,
    gdsOfficeId: 'FRA1A2291',
    notes: 'NDC direct connect active. Surcharge waiver granted.'
  },
  {
    id: 'sup-marriott',
    code: 'MAR',
    name: 'Marriott International Luxury Brands',
    category: 'hotel_chain',
    contactName: 'Elena Rostova',
    contactEmail: 'luxuryagency@marriott.com',
    contactPhone: '+1 301 380 3000',
    contractType: 'direct_contract',
    defaultCommissionRate: 10.0,
    paymentTerms: 'net_30',
    creditLimit: 85000,
    balancePayable: 12400,
    rating: 4.8,
    activeContractsCount: 6,
    notes: 'Luminous & STARS travel advisor program with daily breakfast & $100 credit.'
  },
  {
    id: 'sup-fourseasons',
    code: 'FS',
    name: 'Four Seasons Hotels & Resorts',
    category: 'hotel_chain',
    contactName: 'Julian Sterling',
    contactEmail: 'preferredpartner@fourseasons.com',
    contactPhone: '+1 800 268 6282',
    contractType: 'direct_contract',
    defaultCommissionRate: 10.0,
    paymentTerms: 'net_30',
    creditLimit: 90000,
    balancePayable: 15800,
    rating: 5.0,
    activeContractsCount: 5,
    notes: 'Four Seasons Preferred Partner exclusive amenities and upgrade priority.'
  },
  {
    id: 'sup-kuoni',
    code: 'KUO',
    name: 'Kuoni Destination Management (Europe)',
    category: 'dmc',
    contactName: 'Sophie Blanchard',
    contactEmail: 'sophie.b@kuoni-dmc.ch',
    contactPhone: '+41 44 325 2111',
    contractType: 'direct_contract',
    defaultCommissionRate: 12.0,
    paymentTerms: 'net_15',
    creditLimit: 60000,
    balancePayable: 8750,
    rating: 4.7,
    activeContractsCount: 3,
    notes: 'High-end Swiss & Italian alps transfers, private guides, VIP rail passes.'
  },
  {
    id: 'sup-asiaworld',
    code: 'AWD',
    name: 'AsiaWorld Enterprise DMC',
    category: 'dmc',
    contactName: 'Katsumi Endo',
    contactEmail: 'groups@asiaworld-dmc.com',
    contactPhone: '+81 3 5500 8900',
    contractType: 'wholesaler',
    defaultCommissionRate: 14.0,
    paymentTerms: 'net_30',
    creditLimit: 50000,
    balancePayable: 6300,
    rating: 4.8,
    activeContractsCount: 2,
    notes: 'Bespoke Japan, Thailand, Singapore inbound itineraries and luxury coaches.'
  },
  {
    id: 'sup-hertz',
    code: 'HTZ',
    name: 'Hertz Global Corporate Fleet',
    category: 'car_rental',
    contactName: 'David Miller',
    contactEmail: 'corporate_desk@hertz.com',
    contactPhone: '+1 800 654 3131',
    contractType: 'direct_contract',
    defaultCommissionRate: 8.0,
    paymentTerms: 'net_30',
    creditLimit: 40000,
    balancePayable: 3100,
    rating: 4.4,
    activeContractsCount: 1,
    notes: 'President Circle fast-track for all corporate accounts.'
  },
  {
    id: 'sup-eurostar',
    code: 'EST',
    name: 'Eurostar International Rail',
    category: 'rail',
    contactName: 'Claire Laurent',
    contactEmail: 'trade@eurostar.com',
    contactPhone: '+44 1233 617575',
    contractType: 'gds_amadeus',
    defaultCommissionRate: 5.0,
    paymentTerms: 'net_7',
    creditLimit: 30000,
    balancePayable: 2150,
    rating: 4.7,
    activeContractsCount: 1,
    notes: 'Direct Amadeus ticketing for London - Paris - Brussels routes.'
  }
];

export const initialCorporateAccounts: CorporateAccount[] = [
  {
    id: 'corp-techcorp',
    companyName: 'TechCorp Global Inc.',
    industry: 'Enterprise Software & Cloud',
    accountManager: 'Marcus Vance (Senior Key Account)',
    billingEmail: 'ap-travel@techcorpglobal.com',
    creditLimit: 250000,
    paymentTerms: 'Net 30 days',
    contractDiscount: 9.5,
    activeTravelersCount: 42,
    totalSpendYTD: 482500,
    travelPolicy: {
      maxHotelDailyRateUSD: 380,
      maxDomesticFlightClass: 'Economy',
      maxIntlFlightClass: 'Business',
      requireApprovalAboveUSD: 3500,
      preferredSuppliers: ['Singapore Airlines', 'Lufthansa Group', 'Marriott International']
    }
  },
  {
    id: 'corp-apex',
    companyName: 'Apex BioPharma Laboratories',
    industry: 'Pharmaceuticals & Clinical Research',
    accountManager: 'Sarah Jenkins',
    billingEmail: 'travelbilling@apexbio.com',
    creditLimit: 180000,
    paymentTerms: 'Net 15 days',
    contractDiscount: 7.0,
    activeTravelersCount: 28,
    totalSpendYTD: 310400,
    travelPolicy: {
      maxHotelDailyRateUSD: 320,
      maxDomesticFlightClass: 'Economy',
      maxIntlFlightClass: 'Premium Economy',
      requireApprovalAboveUSD: 2500,
      preferredSuppliers: ['Emirates Airline', 'Lufthansa Group', 'Kuoni Destination Management (Europe)']
    }
  },
  {
    id: 'corp-nexus',
    companyName: 'Nexus Capital Partners',
    industry: 'Private Equity & Venture Capital',
    accountManager: 'Marcus Vance (Senior Key Account)',
    billingEmail: 'ops-invoices@nexuscap.com',
    creditLimit: 300000,
    paymentTerms: 'Net 30 days',
    contractDiscount: 10.0,
    activeTravelersCount: 19,
    totalSpendYTD: 524000,
    travelPolicy: {
      maxHotelDailyRateUSD: 550,
      maxDomesticFlightClass: 'Business',
      maxIntlFlightClass: 'Business',
      requireApprovalAboveUSD: 6000,
      preferredSuppliers: ['Emirates Airline', 'Singapore Airlines', 'Four Seasons Hotels & Resorts']
    }
  }
];

export const initialBookings: Booking[] = [
  {
    id: 'bk-94021',
    bookingRef: 'VO-94021',
    pnrCode: '7XQ9L2',
    type: 'corporate',
    title: 'Q4 Executive Leadership Summit - London & Zurich',
    clientName: 'TechCorp Global Inc.',
    clientEmail: 'ap-travel@techcorpglobal.com',
    clientPhone: '+1 415 889 2000',
    corporateId: 'corp-techcorp',
    corporateCostCenter: 'CC-ENG-EXEC-401',
    travelPolicyCompliance: 'compliant',
    policyNotes: 'All flight classes (Business long-haul) and hotel limits ($345/night) comply with policy limits.',
    status: 'ticketed',
    bookingDate: '2026-09-18',
    travelStartDate: '2026-10-12',
    travelEndDate: '2026-10-18',
    primaryDestination: 'London, United Kingdom & Zurich, Switzerland',
    passengers: [
      {
        id: 'pax-1',
        title: 'Dr.',
        firstName: 'Alexander',
        lastName: 'Wright',
        email: 'a.wright@techcorpglobal.com',
        phone: '+1 415 882 1092',
        passportNumber: 'PA9821443',
        passportExpiry: '2029-05-14',
        nationality: 'United States',
        frequentFlyer: 'SQ 9823481 (PPS Club)',
        specialRequests: 'Window seat, diabetic meal'
      },
      {
        id: 'pax-2',
        title: 'Ms.',
        firstName: 'Samantha',
        lastName: 'Lin',
        email: 's.lin@techcorpglobal.com',
        phone: '+1 415 882 1095',
        passportNumber: 'PA7719208',
        passportExpiry: '2030-11-20',
        nationality: 'United States',
        frequentFlyer: 'LH 2291040 (Senator)',
        specialRequests: 'Aisle seat, gluten-free'
      }
    ],
    segments: [
      {
        id: 'seg-101',
        type: 'flight',
        supplierId: 'sup-singapore',
        supplierName: 'Singapore Airlines',
        confirmationRef: 'SQ-FL-8819',
        title: 'SFO -> LHR (SQ34 - Business Class)',
        description: 'San Francisco Int (SFO) to London Heathrow (LHR) • 2x Business Class Tickets',
        startDateTime: '2026-10-12T19:30:00',
        endDateTime: '2026-10-13T13:45:00',
        origin: 'SFO',
        destination: 'LHR',
        netCost: 7400,
        grossAmount: 8200,
        commissionRate: 6.0,
        commissionAmount: 492,
        currency: 'USD',
        status: 'ticketed'
      },
      {
        id: 'seg-102',
        type: 'hotel',
        supplierId: 'sup-marriott',
        supplierName: 'Marriott International Luxury Brands',
        confirmationRef: 'MAR-LN-44910',
        title: 'JW Marriott Grosvenor House London (3 Nights)',
        description: '2x Executive Park View Suites with lounge access • Mayfair, London',
        startDateTime: '2026-10-13T15:00:00',
        endDateTime: '2026-10-16T11:00:00',
        destination: 'London, UK',
        netCost: 2600,
        grossAmount: 3100,
        commissionRate: 10.0,
        commissionAmount: 310,
        currency: 'USD',
        status: 'confirmed'
      },
      {
        id: 'seg-103',
        type: 'flight',
        supplierId: 'sup-lufthansa',
        supplierName: 'Lufthansa Group (LH/LX/OS)',
        confirmationRef: 'LX-4091',
        title: 'LHR -> ZRH (LX325 - European Business)',
        description: 'London Heathrow to Zurich Airport • Swiss Int Air Lines',
        startDateTime: '2026-10-16T14:15:00',
        endDateTime: '2026-10-16T17:00:00',
        origin: 'LHR',
        destination: 'ZRH',
        netCost: 920,
        grossAmount: 1100,
        commissionRate: 4.5,
        commissionAmount: 49.5,
        currency: 'USD',
        status: 'ticketed'
      },
      {
        id: 'seg-104',
        type: 'transfer',
        supplierId: 'sup-kuoni',
        supplierName: 'Kuoni Destination Management (Europe)',
        confirmationRef: 'KUO-CH-119',
        title: 'Mercedes S-Class VIP Chauffeur Transfer Zurich',
        description: 'Zurich Airport to Baur au Lac Hotel & 2-day on-call executive dispatch',
        startDateTime: '2026-10-16T17:30:00',
        endDateTime: '2026-10-18T10:00:00',
        destination: 'Zurich, Switzerland',
        netCost: 1250,
        grossAmount: 1650,
        commissionRate: 12.0,
        commissionAmount: 198,
        currency: 'USD',
        status: 'confirmed'
      }
    ],
    financials: {
      totalNetCost: 12170,
      totalGrossAmount: 14050,
      markupAmount: 830.5,
      markupPercentage: 6.8,
      totalCommissionEarned: 1049.5,
      agentSplitRate: 40.0,
      agentCommissionShare: 419.8,
      agencyNetProfit: 1460.2,
      invoiceStatus: 'invoiced',
      supplierPaymentStatus: 'authorized',
      currency: 'USD'
    },
    agentId: 'agt-101',
    agentName: 'Marcus Vance',
    internalNotes: 'Corporate VIPs. Requested high-floor rooms facing Hyde Park in London.',
    timeline: [
      {
        id: 'ev-1',
        timestamp: '2026-09-18 10:14',
        actor: 'Marcus Vance',
        action: 'Booking created from Amadeus GDS import',
        note: 'PNR 7XQ9L2 generated with SQ & LX segments'
      },
      {
        id: 'ev-2',
        timestamp: '2026-09-18 14:30',
        actor: 'Marcus Vance',
        action: 'Corporate Policy Verified',
        note: 'Checked against TechCorp limits. Auto-approved.'
      },
      {
        id: 'ev-3',
        timestamp: '2026-09-19 09:00',
        actor: 'Ticketing Robot',
        action: 'E-Tickets Issued',
        note: 'E-Ticket Nos: 618-9921004128 and 618-9921004129'
      },
      {
        id: 'ev-4',
        timestamp: '2026-09-20 11:20',
        actor: 'Billing System',
        action: 'Invoice #INV-2026-0881 Issued',
        note: 'Sent to ap-travel@techcorpglobal.com'
      }
    ]
  },
  {
    id: 'bk-94022',
    bookingRef: 'VO-94022',
    pnrCode: '8KP11Z',
    type: 'leisure',
    title: 'Ultra-Luxury Maldives Overwater Retreat',
    clientName: 'Lord Arthur & Lady Clara Sterling',
    clientEmail: 'sterling.family.office@mayfairholdings.co.uk',
    clientPhone: '+44 20 7946 0912',
    travelPolicyCompliance: 'compliant',
    status: 'confirmed',
    bookingDate: '2026-09-22',
    travelStartDate: '2026-11-04',
    travelEndDate: '2026-11-12',
    primaryDestination: 'Noonu Atoll, Maldives',
    passengers: [
      {
        id: 'pax-3',
        title: 'Lord',
        firstName: 'Arthur',
        lastName: 'Sterling',
        email: 'a.sterling@mayfairholdings.co.uk',
        phone: '+44 7700 900077',
        passportNumber: 'GB9081294',
        passportExpiry: '2031-02-18',
        nationality: 'United Kingdom',
        frequentFlyer: 'EK 882001 (Platinum)',
        specialRequests: 'Dom Pérignon 2012 on arrival, gluten-sensitive'
      },
      {
        id: 'pax-4',
        title: 'Lady',
        firstName: 'Clara',
        lastName: 'Sterling',
        email: 'clara@mayfairholdings.co.uk',
        phone: '+44 7700 900078',
        passportNumber: 'GB9081295',
        passportExpiry: '2031-03-22',
        nationality: 'United Kingdom',
        specialRequests: 'Sunset facing villa, private yoga instructor'
      }
    ],
    segments: [
      {
        id: 'seg-201',
        type: 'flight',
        supplierId: 'sup-emirates',
        supplierName: 'Emirates Airline',
        confirmationRef: 'EK-FD-9941',
        title: 'LHR -> DXB -> MLE (First Class Suites)',
        description: 'London Heathrow to Male via Dubai • Private A380 First Class Shower Suites',
        startDateTime: '2026-11-04T13:40:00',
        endDateTime: '2026-11-05T08:30:00',
        origin: 'LHR',
        destination: 'MLE',
        netCost: 15800,
        grossAmount: 17500,
        commissionRate: 5.5,
        commissionAmount: 962.5,
        currency: 'USD',
        status: 'ticketed'
      },
      {
        id: 'seg-202',
        type: 'hotel',
        supplierId: 'sup-fourseasons',
        supplierName: 'Four Seasons Hotels & Resorts',
        confirmationRef: 'FS-MLE-88190',
        title: 'Four Seasons Resort Maldives at Landaa Giraavaru',
        description: '7 Nights in Premier Ocean Overwater Villa with Pool • Full Board + Spa Credits',
        startDateTime: '2026-11-05T12:00:00',
        endDateTime: '2026-11-12T10:00:00',
        destination: 'Baa Atoll, Maldives',
        netCost: 19400,
        grossAmount: 23200,
        commissionRate: 10.0,
        commissionAmount: 2320,
        currency: 'USD',
        status: 'confirmed'
      },
      {
        id: 'seg-203',
        type: 'transfer',
        supplierId: 'sup-fourseasons',
        supplierName: 'Four Seasons Hotels & Resorts',
        confirmationRef: 'FS-TR-004',
        title: 'The Flying Triggerfish - Private Seaplane Roundtrip',
        description: 'Exclusive luxury 8-seat VIP amphibian seaplane transfer MLE to Landaa',
        startDateTime: '2026-11-05T09:30:00',
        endDateTime: '2026-11-12T12:00:00',
        destination: 'Maldives',
        netCost: 2400,
        grossAmount: 2900,
        commissionRate: 10.0,
        commissionAmount: 290,
        currency: 'USD',
        status: 'confirmed'
      }
    ],
    financials: {
      totalNetCost: 37600,
      totalGrossAmount: 43600,
      markupAmount: 2427.5,
      markupPercentage: 6.4,
      totalCommissionEarned: 3572.5,
      agentSplitRate: 45.0,
      agentCommissionShare: 1607.63,
      agencyNetProfit: 4392.37,
      invoiceStatus: 'paid',
      supplierPaymentStatus: 'settled',
      currency: 'USD'
    },
    agentId: 'agt-102',
    agentName: 'Elena Rostova',
    internalNotes: 'Ultra-VIP clients celebrating 15th wedding anniversary. Coordinated with GM directly.',
    timeline: [
      {
        id: 'ev-21',
        timestamp: '2026-09-22 14:00',
        actor: 'Elena Rostova',
        action: 'Custom Bespoke Leisure File Created',
        note: 'Consulted on private island choices'
      },
      {
        id: 'ev-22',
        timestamp: '2026-09-23 16:40',
        actor: 'Elena Rostova',
        action: 'Deposit Received & Confirmed',
        note: 'Wire transfer of $43,600 cleared via HSBC Private'
      }
    ]
  },
  {
    id: 'bk-94023',
    bookingRef: 'VO-94023',
    pnrCode: '4MB29P',
    type: 'corporate',
    title: 'Biotech Clinical Trials Review - Zurich Symposium',
    clientName: 'Apex BioPharma Laboratories',
    clientEmail: 'travelbilling@apexbio.com',
    clientPhone: '+1 617 555 0192',
    corporateId: 'corp-apex',
    corporateCostCenter: 'CC-RD-CLINICAL-109',
    travelPolicyCompliance: 'exception_approved',
    policyNotes: 'Hotel exceeds standard $320 cap ($385/night) due to symposium convention venue rate. Approved by VP Finance.',
    status: 'confirmed',
    bookingDate: '2026-09-24',
    travelStartDate: '2026-10-24',
    travelEndDate: '2026-10-29',
    primaryDestination: 'Zurich & Basel, Switzerland',
    passengers: [
      {
        id: 'pax-5',
        title: 'Prof.',
        firstName: 'Henrik',
        lastName: 'Vogel',
        email: 'h.vogel@apexbio.com',
        phone: '+1 617 555 8821',
        passportNumber: 'DE8821034',
        passportExpiry: '2028-09-10',
        nationality: 'Germany',
        frequentFlyer: 'LH 9918230',
        specialRequests: 'Quiet room'
      },
      {
        id: 'pax-6',
        title: 'Dr.',
        firstName: 'Valerie',
        lastName: 'Rios',
        email: 'v.rios@apexbio.com',
        phone: '+1 617 555 8829',
        passportNumber: 'US4409124',
        passportExpiry: '2029-01-14',
        nationality: 'United States',
        frequentFlyer: 'UA 1092841',
        specialRequests: 'Vegetarian'
      }
    ],
    segments: [
      {
        id: 'seg-301',
        type: 'flight',
        supplierId: 'sup-lufthansa',
        supplierName: 'Lufthansa Group (LH/LX/OS)',
        confirmationRef: 'LH-BOS-771',
        title: 'BOS -> ZRH (Swiss Premium Economy)',
        description: 'Boston Logan to Zurich Kloten Nonstop • 2x Premium Economy',
        startDateTime: '2026-10-24T18:10:00',
        endDateTime: '2026-10-25T07:45:00',
        origin: 'BOS',
        destination: 'ZRH',
        netCost: 3200,
        grossAmount: 3600,
        commissionRate: 4.5,
        commissionAmount: 162,
        currency: 'USD',
        status: 'confirmed'
      },
      {
        id: 'seg-302',
        type: 'hotel',
        supplierId: 'sup-marriott',
        supplierName: 'Marriott International Luxury Brands',
        confirmationRef: 'MAR-ZRH-902',
        title: 'Zurich Marriott Hotel (4 Nights)',
        description: '2x Deluxe Rooms by the Limmat river • Walking distance to Congress Hall',
        startDateTime: '2026-10-25T14:00:00',
        endDateTime: '2026-10-29T11:00:00',
        destination: 'Zurich, Switzerland',
        netCost: 2600,
        grossAmount: 3080,
        commissionRate: 10.0,
        commissionAmount: 308,
        currency: 'USD',
        status: 'confirmed'
      }
    ],
    financials: {
      totalNetCost: 5800,
      totalGrossAmount: 6680,
      markupAmount: 410,
      markupPercentage: 7.0,
      totalCommissionEarned: 470,
      agentSplitRate: 40.0,
      agentCommissionShare: 188,
      agencyNetProfit: 692,
      invoiceStatus: 'invoiced',
      supplierPaymentStatus: 'pending',
      currency: 'USD'
    },
    agentId: 'agt-103',
    agentName: 'Sarah Jenkins',
    internalNotes: 'Exception approval attached in file notes. Invoiced to Apex Net 15.',
    timeline: [
      {
        id: 'ev-31',
        timestamp: '2026-09-24 11:15',
        actor: 'Sarah Jenkins',
        action: 'Policy Exception Triggered & Approved',
        note: 'VP Finance signed exception for Swiss conference period rate surge'
      }
    ]
  },
  {
    id: 'bk-94024',
    bookingRef: 'VO-94024',
    pnrCode: '3JW99T',
    type: 'leisure',
    title: 'Japan Autumn Discovery & Cultural Heritage',
    clientName: 'The Montgomery Family (4 Pax)',
    clientEmail: 'c.montgomery@architecturaldesign.com',
    clientPhone: '+1 212 555 7710',
    travelPolicyCompliance: 'compliant',
    status: 'invoiced',
    bookingDate: '2026-09-25',
    travelStartDate: '2026-11-15',
    travelEndDate: '2026-11-26',
    primaryDestination: 'Tokyo, Kyoto & Hakone, Japan',
    passengers: [
      {
        id: 'pax-7',
        title: 'Mr.',
        firstName: 'Charles',
        lastName: 'Montgomery',
        email: 'c.montgomery@architecturaldesign.com',
        phone: '+1 212 555 7710',
        passportNumber: 'US8912301',
        passportExpiry: '2030-08-11',
        nationality: 'United States',
        frequentFlyer: 'SQ 441092'
      },
      {
        id: 'pax-8',
        title: 'Mrs.',
        firstName: 'Helena',
        lastName: 'Montgomery',
        email: 'h.montgomery@gmail.com',
        phone: '+1 212 555 7712',
        passportNumber: 'US8912302',
        passportExpiry: '2030-08-11',
        nationality: 'United States'
      }
    ],
    segments: [
      {
        id: 'seg-401',
        type: 'flight',
        supplierId: 'sup-singapore',
        supplierName: 'Singapore Airlines',
        confirmationRef: 'SQ-JFK-HND',
        title: 'JFK -> HND via SIN (Premium Economy)',
        description: 'New York JFK to Tokyo Haneda • 2x Premium Economy Tickets',
        startDateTime: '2026-11-15T09:00:00',
        endDateTime: '2026-11-16T18:30:00',
        origin: 'JFK',
        destination: 'HND',
        netCost: 4800,
        grossAmount: 5400,
        commissionRate: 6.0,
        commissionAmount: 324,
        currency: 'USD',
        status: 'ticketed'
      },
      {
        id: 'seg-402',
        type: 'activity',
        supplierId: 'sup-asiaworld',
        supplierName: 'AsiaWorld Enterprise DMC',
        confirmationRef: 'AWD-JP-778',
        title: 'Private Kyoto Tea Ceremony & Master Temple Tour',
        description: 'Exclusive access to Daitoku-ji sub-temple with zen master guide',
        startDateTime: '2026-11-19T10:00:00',
        endDateTime: '2026-11-19T16:00:00',
        destination: 'Kyoto, Japan',
        netCost: 1400,
        grossAmount: 1850,
        commissionRate: 14.0,
        commissionAmount: 259,
        currency: 'USD',
        status: 'confirmed'
      },
      {
        id: 'seg-403',
        type: 'hotel',
        supplierId: 'sup-fourseasons',
        supplierName: 'Four Seasons Hotels & Resorts',
        confirmationRef: 'FS-KYO-1092',
        title: 'Four Seasons Hotel Kyoto (5 Nights)',
        description: 'Premier Garden View Room overlooking 800-year-old Shakusui-en pond garden',
        startDateTime: '2026-11-18T15:00:00',
        endDateTime: '2026-11-23T11:00:00',
        destination: 'Kyoto, Japan',
        netCost: 6500,
        grossAmount: 7800,
        commissionRate: 10.0,
        commissionAmount: 780,
        currency: 'USD',
        status: 'confirmed'
      }
    ],
    financials: {
      totalNetCost: 12700,
      totalGrossAmount: 15050,
      markupAmount: 987,
      markupPercentage: 7.7,
      totalCommissionEarned: 1363,
      agentSplitRate: 40.0,
      agentCommissionShare: 545.2,
      agencyNetProfit: 1804.8,
      invoiceStatus: 'partially_paid',
      supplierPaymentStatus: 'pending',
      currency: 'USD'
    },
    agentId: 'agt-101',
    agentName: 'Marcus Vance',
    internalNotes: 'Clients love traditional architecture and Michelin kaiseki experiences.',
    timeline: [
      {
        id: 'ev-41',
        timestamp: '2026-09-25 15:30',
        actor: 'Marcus Vance',
        action: 'Itinerary accepted and booking confirmed',
        note: 'Deposit collected, remaining balance due Oct 20'
      }
    ]
  },
  {
    id: 'bk-94025',
    bookingRef: 'VO-94025',
    pnrCode: '5TR82A',
    type: 'corporate',
    title: 'Nexus Capital - Asia Investment Roadshow Singapore',
    clientName: 'Nexus Capital Partners',
    clientEmail: 'ops-invoices@nexuscap.com',
    clientPhone: '+1 212 909 3300',
    corporateId: 'corp-nexus',
    corporateCostCenter: 'CC-PE-ASIA-770',
    travelPolicyCompliance: 'compliant',
    policyNotes: 'All bookings aligned with Nexus Partner Tier travel provisions.',
    status: 'draft',
    bookingDate: '2026-09-28',
    travelStartDate: '2026-12-01',
    travelEndDate: '2026-12-07',
    primaryDestination: 'Singapore & Hong Kong',
    passengers: [
      {
        id: 'pax-9',
        title: 'Mr.',
        firstName: 'Julian',
        lastName: 'Cross',
        email: 'j.cross@nexuscap.com',
        phone: '+1 212 909 3301',
        passportNumber: 'US7710294',
        passportExpiry: '2032-06-15',
        nationality: 'United States',
        frequentFlyer: 'SQ 990142 (PPS Solitaire)'
      }
    ],
    segments: [
      {
        id: 'seg-501',
        type: 'flight',
        supplierId: 'sup-singapore',
        supplierName: 'Singapore Airlines',
        confirmationRef: 'SQ-HOLD-99',
        title: 'EWR -> SIN Nonstop (Business Class)',
        description: 'Newark to Singapore Changi Nonstop World Longest Flight (SQ21)',
        startDateTime: '2026-12-01T10:00:00',
        endDateTime: '2026-12-02T17:30:00',
        origin: 'EWR',
        destination: 'SIN',
        netCost: 8900,
        grossAmount: 9800,
        commissionRate: 6.0,
        commissionAmount: 588,
        currency: 'USD',
        status: 'on_request'
      },
      {
        id: 'seg-502',
        type: 'hotel',
        supplierId: 'sup-marriott',
        supplierName: 'Marriott International Luxury Brands',
        confirmationRef: 'MAR-RC-SIN-40',
        title: 'The Ritz-Carlton, Millenia Singapore (5 Nights)',
        description: 'Club Marina Bay View Suite with Ritz Club privileges',
        startDateTime: '2026-12-02T19:00:00',
        endDateTime: '2026-12-07T11:00:00',
        destination: 'Singapore',
        netCost: 3800,
        grossAmount: 4500,
        commissionRate: 10.0,
        commissionAmount: 450,
        currency: 'USD',
        status: 'on_request'
      }
    ],
    financials: {
      totalNetCost: 12700,
      totalGrossAmount: 14300,
      markupAmount: 562,
      markupPercentage: 4.4,
      totalCommissionEarned: 1038,
      agentSplitRate: 40.0,
      agentCommissionShare: 415.2,
      agencyNetProfit: 1184.8,
      invoiceStatus: 'unbilled',
      supplierPaymentStatus: 'pending',
      currency: 'USD'
    },
    agentId: 'agt-101',
    agentName: 'Marcus Vance',
    internalNotes: 'Draft hold on seat inventory expiring in 48 hours. Awaiting final board agenda confirmation.',
    timeline: [
      {
        id: 'ev-51',
        timestamp: '2026-09-28 09:30',
        actor: 'Marcus Vance',
        action: 'Draft PNR Created on Sabre GDS',
        note: 'Inventory held under airline ticketing time-limit rule'
      }
    ]
  }
];

export const initialItineraries: Itinerary[] = [
  {
    id: 'itin-101',
    title: 'Global Tech Executive Roadshow: London & Zurich',
    clientName: 'TechCorp Global Inc.',
    clientEmail: 'ap-travel@techcorpglobal.com',
    tripType: 'corporate',
    destination: 'London & Zurich',
    startDate: '2026-10-12',
    endDate: '2026-10-18',
    heroImage: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1200&q=80',
    overview: 'Seamless high-tier corporate delegation itinerary for TechCorp senior executives attending EMEA cloud symposiums and investor meetings.',
    totalCostEstimate: 12170,
    recommendedSellingPrice: 14050,
    targetMarginPercent: 15.4,
    status: 'booked',
    createdAt: '2026-09-15',
    inclusions: [
      'Singapore Airlines Business Class SFO-LHR',
      '3 Nights at JW Marriott Grosvenor House London in Executive Suites',
      'VIP Airport Meet & Assist upon arrival at LHR Terminal 2',
      'Swiss International Air Lines Club Europe LHR-ZRH',
      '2 Nights at Baur au Lac Zurich with Lake View',
      'Dedicated Chauffeur Service on standby for all executive meetings'
    ],
    exclusions: [
      'Personal mini-bar and incidental expenses',
      'Weekend extension hotel supplements',
      'Additional baggage beyond Business Class 2x32kg allowance'
    ],
    days: [
      {
        dayNumber: 1,
        date: '2026-10-12',
        title: 'Transatlantic Departure from San Francisco',
        description: 'Check-in at SFO Terminal G, lounge access at SilverKris Lounge.',
        items: [
          {
            id: 'it-1',
            time: '19:30',
            type: 'flight',
            title: 'SQ34 SFO to London Heathrow (LHR)',
            location: 'San Francisco International Terminal G',
            description: 'Departs 19:30 PST. Lie-flat Business Class suites with Book the Cook pre-flight dining.',
            confirmationNumber: 'SQ-FL-8819',
            badge: 'Business Class'
          }
        ]
      },
      {
        dayNumber: 2,
        date: '2026-10-13',
        title: 'London Arrival & Mayfair Check-in',
        description: 'Tarmac fast-track immigration and private transit to hotel.',
        items: [
          {
            id: 'it-2',
            time: '13:45',
            type: 'transfer',
            title: 'LHR VIP Meet & Assist to Grosvenor House',
            location: 'Heathrow Airport Terminal 2',
            description: 'Greeter holding TechCorp signage at jetbridge. Luggage portered directly to Mercedes V-Class.',
            badge: 'Chauffeur'
          },
          {
            id: 'it-3',
            time: '15:30',
            type: 'hotel',
            title: 'Check-in: JW Marriott Grosvenor House',
            location: '86-90 Park Lane, Mayfair, London W1K 7TN',
            description: 'Executive Park View Suites. Access to Executive Lounge on Ground Floor.',
            confirmationNumber: 'MAR-LN-44910'
          },
          {
            id: 'it-4',
            time: '19:00',
            type: 'meeting',
            title: 'Welcome Dinner with EMEA Country Heads',
            location: 'Corrigan’s Mayfair Private Room',
            description: 'Pre-ordered 4-course tasting menu with curated Burgundy pairings.'
          }
        ]
      },
      {
        dayNumber: 3,
        date: '2026-10-14',
        title: 'EMEA Enterprise Summit Day 1',
        description: 'Full day executive keynote and partner meetings.',
        items: [
          {
            id: 'it-5',
            time: '08:30',
            type: 'transfer',
            title: 'Chauffeur Transfer to ExCeL London',
            location: 'Pick-up Grosvenor House lobby',
            description: 'Dedicated driver on standby throughout the day.'
          },
          {
            id: 'it-6',
            time: '09:30',
            type: 'meeting',
            title: 'Keynote Session & Investor Briefings',
            location: 'ExCeL Platinum Executive Suite',
            description: 'Speech by Dr. Alexander Wright at 11:15 AM.'
          }
        ]
      },
      {
        dayNumber: 4,
        date: '2026-10-15',
        title: 'Financial District Analyst Meetings',
        description: 'City of London institutional meetings.',
        items: [
          {
            id: 'it-7',
            time: '10:00',
            type: 'meeting',
            title: 'Meeting with Goldman Sachs & Morgan Stanley Analysts',
            location: 'Plumtree Court, City of London',
            description: 'Discussion on cloud margins and AI infrastructure rollout.'
          }
        ]
      },
      {
        dayNumber: 5,
        date: '2026-10-16',
        title: 'Transit to Zurich & Swiss Banking Delegation',
        description: 'Short flight to Zurich and lakefront luxury accommodation.',
        items: [
          {
            id: 'it-8',
            time: '11:45',
            type: 'transfer',
            title: 'Transfer to London Heathrow Terminal 2',
            location: 'Park Lane to LHR',
            description: 'Lufthansa Group Senator Lounge check-in.'
          },
          {
            id: 'it-9',
            time: '14:15',
            type: 'flight',
            title: 'LX325 LHR to Zurich (ZRH)',
            location: 'London Heathrow to Zurich Kloten',
            description: 'Swiss European Business. Arrival 17:00 local time.',
            confirmationNumber: 'LX-4091'
          },
          {
            id: 'it-10',
            time: '17:45',
            type: 'hotel',
            title: 'Check-in: Baur au Lac Zurich',
            location: 'Talstrasse 1, 8001 Zürich',
            description: 'Deluxe Lake View Suites with private park views.'
          }
        ]
      }
    ]
  },
  {
    id: 'itin-102',
    title: 'Bespoke Grand Tour of Switzerland & Italian Lakes',
    clientName: 'Lord Arthur & Lady Clara Sterling',
    clientEmail: 'sterling.family.office@mayfairholdings.co.uk',
    tripType: 'leisure',
    destination: 'Geneva, Zermatt, Lake Como & Milan',
    startDate: '2026-10-01',
    endDate: '2026-10-10',
    heroImage: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=1200&q=80',
    overview: 'An exquisite autumn journey across Alpine glaciers and tranquil lakeside villas with private vintage boat cruises and helicopter glacier landings.',
    totalCostEstimate: 28500,
    recommendedSellingPrice: 34200,
    targetMarginPercent: 20.0,
    status: 'proposal_sent',
    createdAt: '2026-09-20',
    inclusions: [
      'First Class Swiss Glacier Express Excellence Class',
      '4 Nights at Mont Cervin Palace Zermatt Matterhorn Suite',
      '3 Nights at Villa d’Este, Lake Como in Lakefront Junior Suite',
      'Private Riva boat 4-hour charter on Lake Como with sommelier',
      'Helicopter flight over Mont Blanc & Matterhorn with glacier champagne toast',
      'Private luxury Mercedes Maybach driver throughout'
    ],
    exclusions: [
      'International flights (ticketed separately)',
      'Gratuities for private guides'
    ],
    days: [
      {
        dayNumber: 1,
        date: '2026-10-01',
        title: 'Arrival in Geneva & Transfer to Zermatt',
        description: 'Private vehicle meet at Geneva Cointrin, scenic drive along Lake Geneva.',
        items: [
          {
            id: 'it-201',
            time: '12:00',
            type: 'transfer',
            title: 'Geneva Airport to Zermatt VIP Terminal',
            location: 'Geneva Airport (GVA)',
            description: 'Mercedes Maybach transition to electro-limousine at Täsch.'
          },
          {
            id: 'it-202',
            time: '16:00',
            type: 'hotel',
            title: 'Check-in: Mont Cervin Palace',
            location: 'Bahnhofstrasse 31, Zermatt',
            description: 'Matterhorn Suite with wood-burning fireplace and panoramic balcony.'
          }
        ]
      },
      {
        dayNumber: 2,
        date: '2026-10-02',
        title: 'Matterhorn Glacier Paradise & Private Helicopter',
        description: 'Ascend Europe’s highest cableway and private Air Zermatt scenic flight.',
        items: [
          {
            id: 'it-203',
            time: '10:00',
            type: 'activity',
            title: 'Air Zermatt Alpine Helicopter Flight',
            location: 'Zermatt Heliport',
            description: 'Glacier landing on Theodul glacier with Krug champagne picnic.'
          }
        ]
      }
    ]
  },
  {
    id: 'itin-103',
    title: 'Singapore FinTech & Private Wealth Delegation',
    clientName: 'Nexus Capital Partners',
    clientEmail: 'ops-invoices@nexuscap.com',
    tripType: 'corporate',
    destination: 'Singapore',
    startDate: '2026-12-01',
    endDate: '2026-12-07',
    heroImage: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=1200&q=80',
    overview: 'High efficiency corporate schedule designed around Singapore FinTech Festival keynotes, MAS regulatory roundtables, and sovereign fund dinners.',
    totalCostEstimate: 12700,
    recommendedSellingPrice: 14300,
    targetMarginPercent: 12.6,
    status: 'draft',
    createdAt: '2026-09-28',
    inclusions: [
      'Singapore Airlines Premium Business Flight EWR-SIN Nonstop',
      'The Ritz-Carlton Millenia Marina Bay Suite with Club Concierge',
      'VIP fast-track Changi JetQuay private terminal services',
      'Private car transfer for all bilateral meetings'
    ],
    exclusions: ['Optional golf passes at Sentosa Golf Club'],
    days: [
      {
        dayNumber: 1,
        date: '2026-12-01',
        title: 'Nonstop Flight to Singapore',
        description: 'World longest flight SQ21 from Newark to Changi Airport.',
        items: [
          {
            id: 'it-301',
            time: '10:00',
            type: 'flight',
            title: 'SQ21 EWR to SIN Nonstop',
            location: 'Newark Liberty International Terminal B',
            description: 'A350-900 Ultra Long Range. 18 hours 45 minutes.',
            badge: 'Business Class'
          }
        ]
      }
    ]
  }
];

export const initialCommissions: CommissionRecord[] = [
  {
    id: 'comm-1',
    bookingId: 'bk-94021',
    bookingRef: 'VO-94021',
    pnrCode: '7XQ9L2',
    agentId: 'agt-101',
    agentName: 'Marcus Vance',
    supplierName: 'Singapore Airlines / Marriott / Swiss',
    grossAmount: 14050,
    totalCommissionEarned: 1049.5,
    agentSplitRate: 40,
    agentPayout: 419.8,
    agencyRetained: 629.7,
    payoutStatus: 'approved',
    settlementDate: '2026-10-31',
    createdAt: '2026-09-20'
  },
  {
    id: 'comm-2',
    bookingId: 'bk-94022',
    bookingRef: 'VO-94022',
    pnrCode: '8KP11Z',
    agentId: 'agt-102',
    agentName: 'Elena Rostova',
    supplierName: 'Emirates Airline / Four Seasons Maldives',
    grossAmount: 43600,
    totalCommissionEarned: 3572.5,
    agentSplitRate: 45,
    agentPayout: 1607.63,
    agencyRetained: 1964.87,
    payoutStatus: 'paid',
    settlementDate: '2026-09-25',
    createdAt: '2026-09-23'
  },
  {
    id: 'comm-3',
    bookingId: 'bk-94023',
    bookingRef: 'VO-94023',
    pnrCode: '4MB29P',
    agentId: 'agt-103',
    agentName: 'Sarah Jenkins',
    supplierName: 'Lufthansa Group / Zurich Marriott',
    grossAmount: 6680,
    totalCommissionEarned: 470,
    agentSplitRate: 40,
    agentPayout: 188,
    agencyRetained: 282,
    payoutStatus: 'accrued',
    createdAt: '2026-09-24'
  },
  {
    id: 'comm-4',
    bookingId: 'bk-94024',
    bookingRef: 'VO-94024',
    pnrCode: '3JW99T',
    agentId: 'agt-101',
    agentName: 'Marcus Vance',
    supplierName: 'Singapore Airlines / AsiaWorld / Four Seasons Kyoto',
    grossAmount: 15050,
    totalCommissionEarned: 1363,
    agentSplitRate: 40,
    agentPayout: 545.2,
    agencyRetained: 817.8,
    payoutStatus: 'accrued',
    createdAt: '2026-09-25'
  }
];
