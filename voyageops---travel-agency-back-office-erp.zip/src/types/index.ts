export type BookingType = 'corporate' | 'leisure';

export type BookingStatus =
  | 'draft'
  | 'confirmed'
  | 'ticketed'
  | 'invoiced'
  | 'completed'
  | 'cancelled';

export type SegmentType = 'flight' | 'hotel' | 'transfer' | 'activity' | 'car_rental' | 'rail';

export type PolicyComplianceStatus = 'compliant' | 'exception_approved' | 'out_of_policy';

export interface Passenger {
  id: string;
  title: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  passportNumber: string;
  passportExpiry: string;
  nationality: string;
  frequentFlyer?: string;
  specialRequests?: string;
}

export interface BookingSegment {
  id: string;
  type: SegmentType;
  supplierId: string;
  supplierName: string;
  confirmationRef: string;
  title: string;
  description: string;
  startDateTime: string;
  endDateTime: string;
  origin?: string;
  destination?: string;
  netCost: number;
  grossAmount: number;
  commissionRate: number; // e.g. 10%
  commissionAmount: number;
  currency: string;
  status: 'confirmed' | 'on_request' | 'ticketed' | 'cancelled';
}

export interface BookingFinancials {
  totalNetCost: number;
  totalGrossAmount: number;
  markupAmount: number;
  markupPercentage: number;
  totalCommissionEarned: number;
  agentSplitRate: number; // percentage agent gets, e.g. 40%
  agentCommissionShare: number;
  agencyNetProfit: number;
  invoiceStatus: 'unbilled' | 'invoiced' | 'partially_paid' | 'paid' | 'overdue';
  supplierPaymentStatus: 'pending' | 'authorized' | 'settled';
  currency: string;
}

export interface BookingEvent {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  note?: string;
}

export interface Booking {
  id: string;
  bookingRef: string; // e.g. VO-94021
  pnrCode: string; // e.g. 7XQ9L2
  type: BookingType;
  title: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  corporateId?: string;
  corporateCostCenter?: string;
  travelPolicyCompliance: PolicyComplianceStatus;
  policyNotes?: string;
  status: BookingStatus;
  bookingDate: string;
  travelStartDate: string;
  travelEndDate: string;
  primaryDestination: string;
  passengers: Passenger[];
  segments: BookingSegment[];
  financials: BookingFinancials;
  agentId: string;
  agentName: string;
  internalNotes: string;
  timeline: BookingEvent[];
}

export type SupplierCategory =
  | 'airline'
  | 'hotel_chain'
  | 'dmc'
  | 'car_rental'
  | 'consolidator'
  | 'rail';

export interface Supplier {
  id: string;
  code: string;
  name: string;
  category: SupplierCategory;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  contractType: 'direct_contract' | 'gds_amadeus' | 'gds_sabre' | 'wholesaler';
  defaultCommissionRate: number;
  paymentTerms: 'net_7' | 'net_15' | 'net_30' | 'prepaid';
  creditLimit: number;
  balancePayable: number;
  rating: number;
  activeContractsCount: number;
  gdsOfficeId?: string;
  notes: string;
}

export interface CorporateAccount {
  id: string;
  companyName: string;
  industry: string;
  accountManager: string;
  billingEmail: string;
  creditLimit: number;
  paymentTerms: string;
  contractDiscount: number; // e.g. 8%
  activeTravelersCount: number;
  totalSpendYTD: number;
  travelPolicy: {
    maxHotelDailyRateUSD: number;
    maxDomesticFlightClass: 'Economy' | 'Premium Economy' | 'Business';
    maxIntlFlightClass: 'Economy' | 'Premium Economy' | 'Business' | 'First';
    requireApprovalAboveUSD: number;
    preferredSuppliers: string[];
  };
}

export interface CommissionRecord {
  id: string;
  bookingId: string;
  bookingRef: string;
  pnrCode: string;
  agentId: string;
  agentName: string;
  supplierName: string;
  grossAmount: number;
  totalCommissionEarned: number;
  agentSplitRate: number;
  agentPayout: number;
  agencyRetained: number;
  payoutStatus: 'accrued' | 'approved' | 'paid';
  settlementDate?: string;
  createdAt: string;
}

export interface ItineraryItem {
  id: string;
  time: string;
  type: SegmentType | 'meeting';
  title: string;
  location: string;
  description: string;
  supplierRef?: string;
  confirmationNumber?: string;
  badge?: string;
}

export interface ItineraryDay {
  dayNumber: number;
  date: string;
  title: string;
  description: string;
  items: ItineraryItem[];
}

export interface Itinerary {
  id: string;
  title: string;
  clientName: string;
  clientEmail: string;
  tripType: BookingType | 'bleisure';
  destination: string;
  startDate: string;
  endDate: string;
  heroImage: string;
  overview: string;
  days: ItineraryDay[];
  inclusions: string[];
  exclusions: string[];
  totalCostEstimate: number;
  recommendedSellingPrice: number;
  targetMarginPercent: number;
  status: 'draft' | 'proposal_sent' | 'client_accepted' | 'booked';
  createdAt: string;
}
