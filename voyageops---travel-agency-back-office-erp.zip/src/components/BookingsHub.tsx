import React, { useState } from 'react';
import { Booking, BookingStatus, BookingType } from '../types';
import { formatUSD, formatDate } from '../utils/formatters';
import {
  Search,
  Plus,
  Filter,
  Plane,
  Building,
  Car,
  Compass,
  FileText,
  Tag,
  AlertTriangle,
  ChevronDown,
  Layers,
  ArrowUpDown,
  ExternalLink,
} from 'lucide-react';

interface BookingsHubProps {
  bookings: Booking[];
  onSelectBooking: (booking: Booking) => void;
  onOpenCreateBooking: () => void;
}

export const BookingsHub: React.FC<BookingsHubProps> = ({
  bookings,
  onSelectBooking,
  onOpenCreateBooking,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | BookingType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | BookingStatus>('all');
  const [sortBy, setSortBy] = useState<'date' | 'gross' | 'margin'>('date');

  const filteredBookings = bookings.filter((b) => {
    const matchesType = typeFilter === 'all' || b.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      b.pnrCode.toLowerCase().includes(q) ||
      b.bookingRef.toLowerCase().includes(q) ||
      b.clientName.toLowerCase().includes(q) ||
      b.title.toLowerCase().includes(q) ||
      b.primaryDestination.toLowerCase().includes(q) ||
      b.passengers.some(
        (p) =>
          p.firstName.toLowerCase().includes(q) ||
          p.lastName.toLowerCase().includes(q) ||
          p.passportNumber.toLowerCase().includes(q)
      );

    return matchesType && matchesStatus && matchesSearch;
  });

  const sortedBookings = [...filteredBookings].sort((a, b) => {
    if (sortBy === 'gross') {
      return b.financials.totalGrossAmount - a.financials.totalGrossAmount;
    }
    if (sortBy === 'margin') {
      return b.financials.agencyNetProfit - a.financials.agencyNetProfit;
    }
    return new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime();
  });

  const getStatusBadge = (status: BookingStatus) => {
    switch (status) {
      case 'ticketed':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'confirmed':
        return 'bg-sky-500/20 text-sky-300 border-sky-500/30';
      case 'invoiced':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      case 'completed':
        return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
      case 'cancelled':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      default:
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="bg-slate-850 p-4 rounded-xl border border-slate-750 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">Active Bookings & PNR Files</h2>
          <p className="text-xs text-slate-400">
            {bookings.length} total files • Multi-passenger itineraries, e-ticket issuance, and accounting status
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search PNR, Passenger, Ref, Account..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:ring-1 focus:ring-indigo-500 w-64"
            />
          </div>

          <button
            onClick={onOpenCreateBooking}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Booking</span>
          </button>
        </div>
      </div>

      {/* Filter and Sort Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        {/* Type and Status filter pills */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1">
          <div className="flex bg-slate-850 p-1 rounded-lg border border-slate-750">
            <button
              onClick={() => setTypeFilter('all')}
              className={`px-3 py-1 rounded font-semibold transition-all ${
                typeFilter === 'all'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => setTypeFilter('corporate')}
              className={`px-3 py-1 rounded font-semibold transition-all ${
                typeFilter === 'corporate'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Corporate
            </button>
            <button
              onClick={() => setTypeFilter('leisure')}
              className={`px-3 py-1 rounded font-semibold transition-all ${
                typeFilter === 'leisure'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Leisure
            </button>
          </div>

          <div className="h-6 w-px bg-slate-750 hidden md:block" />

          {/* Status Pills */}
          <div className="flex bg-slate-850 p-1 rounded-lg border border-slate-750">
            {(['all', 'draft', 'confirmed', 'ticketed', 'invoiced', 'completed'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded font-medium capitalize transition-all ${
                  statusFilter === st
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Sort selector */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 flex items-center space-x-1">
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>Sort by:</span>
          </span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-850 border border-slate-750 rounded-lg px-2.5 py-1 text-slate-200 text-xs focus:ring-1 focus:ring-indigo-500"
          >
            <option value="date">Booking Date</option>
            <option value="gross">Gross Value (High-Low)</option>
            <option value="margin">Agency Profit (High-Low)</option>
          </select>
        </div>
      </div>

      {/* Bookings Table */}
      <div className="bg-slate-850 rounded-xl border border-slate-750 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/70 text-slate-400 uppercase font-semibold border-b border-slate-750">
              <tr>
                <th className="py-3 px-4">PNR / File Ref</th>
                <th className="py-3 px-4">Client / Trip Title</th>
                <th className="py-3 px-4">Destination & Dates</th>
                <th className="py-3 px-4">Pax Manifest</th>
                <th className="py-3 px-4">Segments</th>
                <th className="py-3 px-4 text-right">Net Cost</th>
                <th className="py-3 px-4 text-right">Gross Price</th>
                <th className="py-3 px-4 text-right">Agency Profit</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-750/70">
              {sortedBookings.map((b) => (
                <tr
                  key={b.id}
                  onClick={() => onSelectBooking(b)}
                  className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3.5 px-4">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-indigo-400 text-sm tracking-wider">
                        {b.pnrCode}
                      </span>
                      {b.travelPolicyCompliance !== 'compliant' && (
                        <span title="Policy exception attached" className="text-amber-400">
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">{b.bookingRef}</div>
                  </td>

                  <td className="py-3.5 px-4 max-w-xs">
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-white truncate">{b.clientName}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                          b.type === 'corporate'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}
                      >
                        {b.type}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{b.title}</p>
                    {b.corporateCostCenter && (
                      <span className="text-[10px] text-slate-500 font-mono">
                        CC: {b.corporateCostCenter}
                      </span>
                    )}
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="font-medium text-slate-200">{b.primaryDestination}</div>
                    <div className="text-[11px] text-slate-500">
                      {formatDate(b.travelStartDate)} – {formatDate(b.travelEndDate)}
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-slate-200">
                      {b.passengers.length} Pax
                    </span>
                    <p className="text-[11px] text-slate-400 truncate max-w-[120px]">
                      {b.passengers.map((p) => p.lastName).join(', ')}
                    </p>
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[11px]">
                      {b.segments.length} lines
                    </span>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {b.segments.map((s) => s.type.substring(0, 3)).join(' • ')}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-right font-mono text-amber-400">
                    {formatUSD(b.financials.totalNetCost)}
                  </td>

                  <td className="py-3.5 px-4 text-right font-mono font-bold text-white">
                    {formatUSD(b.financials.totalGrossAmount)}
                  </td>

                  <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">
                    {formatUSD(b.financials.agencyNetProfit)}
                    <span className="block text-[10px] text-slate-500 font-normal">
                      +{b.financials.markupPercentage}%
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${getStatusBadge(
                        b.status
                      )}`}
                    >
                      {b.status}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBooking(b);
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded text-[11px] font-medium border border-slate-700 transition-colors"
                    >
                      Manage File
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
