import React from 'react';
import { Booking, CorporateAccount, Supplier, CommissionRecord } from '../types';
import { formatUSD, formatDate } from '../utils/formatters';
import {
  TrendingUp,
  DollarSign,
  Briefcase,
  Users,
  AlertTriangle,
  Plane,
  Building,
  ArrowRight,
  ShieldCheck,
  Clock,
  Compass,
  FileText,
  Calendar,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface DashboardViewProps {
  bookings: Booking[];
  suppliers: Supplier[];
  corporateAccounts: CorporateAccount[];
  commissions: CommissionRecord[];
  onSelectBooking: (booking: Booking) => void;
  onNavigateTab: (tab: string) => void;
  onOpenCreateBooking: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  bookings,
  suppliers,
  corporateAccounts,
  commissions,
  onSelectBooking,
  onNavigateTab,
  onOpenCreateBooking,
}) => {
  // Aggregate Metrics
  const totalTTV = bookings.reduce((sum, b) => sum + b.financials.totalGrossAmount, 0);
  const totalNetCost = bookings.reduce((sum, b) => sum + b.financials.totalNetCost, 0);
  const totalAgencyProfit = bookings.reduce((sum, b) => sum + b.financials.agencyNetProfit, 0);
  const totalCommissions = bookings.reduce((sum, b) => sum + b.financials.totalCommissionEarned, 0);
  const totalSupplierPayables = suppliers.reduce((sum, s) => sum + s.balancePayable, 0);

  const corporateBookings = bookings.filter((b) => b.type === 'corporate');
  const leisureBookings = bookings.filter((b) => b.type === 'leisure');

  const corporateSpend = corporateBookings.reduce((sum, b) => sum + b.financials.totalGrossAmount, 0);
  const leisureSpend = leisureBookings.reduce((sum, b) => sum + b.financials.totalGrossAmount, 0);
  const corpPercent = totalTTV > 0 ? Math.round((corporateSpend / totalTTV) * 100) : 50;

  // Urgent action items
  const uninvoicedBookings = bookings.filter(
    (b) => b.financials.invoiceStatus === 'unbilled' && b.status !== 'cancelled'
  );
  const policyExceptions = bookings.filter(
    (b) => b.travelPolicyCompliance === 'exception_approved' || b.travelPolicyCompliance === 'out_of_policy'
  );

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions */}
      <div className="bg-gradient-to-r from-indigo-900/60 via-slate-850 to-slate-850 rounded-2xl border border-indigo-500/30 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2 border border-indigo-500/30">
            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
            <span>VoyageOps Global Operations Center</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">Travel Agency Operations & Financials</h1>
          <p className="text-xs text-slate-400 max-w-xl mt-1">
            Real-time GDS bookings, agent commission ledgers, corporate policy compliance, and supplier contracts for corporate & leisure accounts.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigateTab('itineraries')}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-colors shadow-sm"
          >
            Itinerary Builder
          </button>
          <button
            onClick={onOpenCreateBooking}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 transition-all flex items-center space-x-2"
          >
            <span>+ Create New Booking</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total Booking Value (TTV)
            </span>
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-bold font-mono text-white">{formatUSD(totalTTV)}</p>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1">
              <span>{bookings.length} Active Files</span>
              <span>•</span>
              <span className="text-emerald-400 font-medium">98.4% On-Schedule</span>
            </div>
          </div>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Agency Net Profit
            </span>
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-bold font-mono text-indigo-400">{formatUSD(totalAgencyProfit)}</p>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1">
              <span>Retained Margin + Markup</span>
              <span>•</span>
              <span className="font-mono text-slate-300">
                {totalTTV > 0 ? ((totalAgencyProfit / totalTTV) * 100).toFixed(1) : 0}% Yield
              </span>
            </div>
          </div>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Commissions Earned
            </span>
            <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400">
              <Compass className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-bold font-mono text-sky-400">{formatUSD(totalCommissions)}</p>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1">
              <span>Suppliers & GDS Overrides</span>
              <span>•</span>
              <span className="text-sky-300 font-semibold">{commissions.length} Claims</span>
            </div>
          </div>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Supplier Payables Due
            </span>
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl font-bold font-mono text-amber-400">{formatUSD(totalSupplierPayables)}</p>
            <div className="flex items-center space-x-2 text-xs text-slate-400 mt-1">
              <span>{suppliers.length} Contract Partners</span>
              <span>•</span>
              <span className="text-amber-300">Net 15 / 30 terms</span>
            </div>
          </div>
        </div>
      </div>

      {/* Middle Section: Portfolio Split & Operations Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Corporate vs Leisure Portfolio Split */}
        <div className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Portfolio Volume Breakdown</h3>
            <span className="text-xs text-indigo-400 font-medium">Corporate vs Leisure</span>
          </div>

          <div className="space-y-3 pt-2">
            {/* Visual ratio bar */}
            <div className="h-4 w-full bg-slate-900 rounded-full overflow-hidden flex p-0.5 border border-slate-750">
              <div
                style={{ width: `${corpPercent}%` }}
                className="bg-indigo-500 rounded-l-full h-full transition-all duration-500"
                title={`Corporate: ${corpPercent}%`}
              />
              <div
                style={{ width: `${100 - corpPercent}%` }}
                className="bg-amber-500 rounded-r-full h-full transition-all duration-500"
                title={`Leisure: ${100 - corpPercent}%`}
              />
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2 text-xs">
              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-750">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                  <span className="font-semibold text-slate-300">Corporate ({corpPercent}%)</span>
                </div>
                <p className="text-lg font-bold font-mono text-white mt-1">{formatUSD(corporateSpend)}</p>
                <p className="text-[11px] text-slate-500">{corporateBookings.length} PNRs • 3 Corporate Accounts</p>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-750">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="font-semibold text-slate-300">Leisure ({100 - corpPercent}%)</span>
                </div>
                <p className="text-lg font-bold font-mono text-white mt-1">{formatUSD(leisureSpend)}</p>
                <p className="text-[11px] text-slate-500">{leisureBookings.length} PNRs • Bespoke VIP FIT</p>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-750/70 text-xs text-slate-400 flex justify-between items-center">
            <span>Corporate Policy Enforcement Active</span>
            <button
              onClick={() => onNavigateTab('corporate')}
              className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
            >
              <span>Manage Rules</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Operational Attention Queue */}
        <div className="lg:col-span-2 bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Back-Office Operations Radar</h3>
            <span className="text-xs text-slate-400">Action Required</span>
          </div>

          <div className="space-y-3">
            {uninvoicedBookings.length > 0 && (
              <div className="p-3 bg-indigo-950/40 rounded-lg border border-indigo-800/60 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-indigo-600/20 text-indigo-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">
                      {uninvoicedBookings.length} Booking(s) Pending Commercial Tax Invoicing
                    </h4>
                    <p className="text-slate-400">
                      Unbilled revenue: {formatUSD(uninvoicedBookings.reduce((s, b) => s + b.financials.totalGrossAmount, 0))}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onSelectBooking(uninvoicedBookings[0])}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold transition-colors shadow-sm"
                >
                  Generate Invoice
                </button>
              </div>
            )}

            {policyExceptions.length > 0 && (
              <div className="p-3 bg-amber-950/40 rounded-lg border border-amber-800/60 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-amber-600/20 text-amber-400">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">
                      {policyExceptions.length} Corporate Policy Exception Logged
                    </h4>
                    <p className="text-slate-400">
                      {policyExceptions[0].clientName} — {policyExceptions[0].policyNotes}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onSelectBooking(policyExceptions[0])}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-semibold transition-colors shadow-sm"
                >
                  Review PNR
                </button>
              </div>
            )}

            <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-750 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-emerald-600/20 text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">IATA BSP / ARC Settlement Synchronization</h4>
                  <p className="text-slate-400">All 3 direct airline contracts synced with Amadeus & Sabre ticketing engines</p>
                </div>
              </div>
              <span className="text-emerald-400 font-semibold font-mono">100% OK</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Bookings Hub */}
      <div className="bg-slate-850 rounded-xl border border-slate-750 overflow-hidden">
        <div className="p-5 border-b border-slate-750 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Recent Active Travel Files (PNRs)</h3>
            <p className="text-xs text-slate-400">Real-time status, client accounts, segments, and margin yields</p>
          </div>
          <button
            onClick={() => onNavigateTab('bookings')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center space-x-1"
          >
            <span>View All Bookings</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/60 text-slate-400 uppercase font-semibold border-b border-slate-750">
              <tr>
                <th className="py-3 px-4">PNR / Ref</th>
                <th className="py-3 px-4">Client / Trip Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Travel Dates</th>
                <th className="py-3 px-4 text-right">Gross Invoiced</th>
                <th className="py-3 px-4 text-right">Agency Margin</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-750/70">
              {bookings.slice(0, 5).map((b) => (
                <tr
                  key={b.id}
                  onClick={() => onSelectBooking(b)}
                  className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3.5 px-4">
                    <div className="font-mono font-bold text-indigo-400 text-sm">{b.pnrCode}</div>
                    <div className="text-[11px] text-slate-500">{b.bookingRef}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white">{b.clientName}</div>
                    <div className="text-[11px] text-slate-400 truncate max-w-xs">{b.title}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                        b.type === 'corporate'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {b.type}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">
                    <div>{formatDate(b.travelStartDate)}</div>
                    <div className="text-[11px] text-slate-500">to {formatDate(b.travelEndDate)}</div>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-white">
                    {formatUSD(b.financials.totalGrossAmount)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">
                    {formatUSD(b.financials.agencyNetProfit)}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${
                        b.status === 'ticketed'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : b.status === 'confirmed'
                          ? 'bg-sky-500/20 text-sky-300 border-sky-500/30'
                          : b.status === 'invoiced'
                          ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      }`}
                    >
                      {b.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBooking(b);
                      }}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold border border-slate-700 transition-colors"
                    >
                      Open File
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
