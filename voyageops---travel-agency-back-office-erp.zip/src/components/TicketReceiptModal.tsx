import React from 'react';
import { Booking } from '../types';
import { formatDate, formatUSD } from '../utils/formatters';
import { Plane, Printer, X, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface TicketReceiptModalProps {
  booking: Booking;
  onClose: () => void;
}

export const TicketReceiptModal: React.FC<TicketReceiptModalProps> = ({ booking, onClose }) => {
  const flightSegments = booking.segments.filter(s => s.type === 'flight');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Controls */}
        <div className="print:hidden flex items-center justify-between px-6 py-4 bg-slate-800/80 border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-lg bg-sky-500/20 text-sky-400">
              <Plane className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-semibold text-white">Electronic Ticket Passenger Itinerary & Receipt</h3>
              <p className="text-xs text-slate-400">GDS Amadeus/Sabre Issue • PNR: {booking.pnrCode}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white text-sm font-medium rounded-lg transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save E-Ticket</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Content */}
        <div className="p-8 md:p-10 bg-white text-slate-900 print:p-0 font-sans" id="printable-ticket">
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4 mb-6">
            <div>
              <div className="text-xl font-black tracking-tight text-slate-900 flex items-center gap-2">
                <Plane className="w-5 h-5 text-sky-600" />
                <span>ELECTRONIC TICKET RECEIPT</span>
              </div>
              <p className="text-xs text-slate-500">IATA Standard Passenger Itinerary / Receipt</p>
              <p className="text-xs text-slate-500">Issuing Agency: VoyageOps Global (IATA: 05-892102)</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-semibold text-slate-500 uppercase">Airline Record Locator</p>
              <p className="text-2xl font-mono font-black text-sky-700 tracking-wider">{booking.pnrCode}</p>
              <p className="text-xs text-slate-500 mt-1">Issue Date: {formatDate(booking.bookingDate)}</p>
            </div>
          </div>

          {/* Passenger Ticket Numbers */}
          <div className="mb-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Ticketed Passengers</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {booking.passengers.map((p, idx) => (
                <div key={p.id || idx} className="p-2.5 bg-white rounded border border-slate-200 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-slate-900">{idx + 1}. {p.lastName.toUpperCase()}/{p.firstName.toUpperCase()} {p.title}</span>
                    <p className="text-slate-500 text-[11px]">Passport: {p.passportNumber || 'VERIFIED'} • {p.frequentFlyer || 'No FF'}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">E-Ticket #</span>
                    <span className="font-mono font-bold text-sky-700">618-{Math.floor(1000000000 + idx * 11 + Math.random() * 9000)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Flight Coupons / Segments */}
          <div className="mb-6">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Flight Segments & Fare Breakdown</h4>
            {flightSegments.length === 0 ? (
              <p className="text-xs text-slate-500 italic p-4 bg-slate-50 rounded">No airline flight segments on this booking file.</p>
            ) : (
              <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Flight / Carrier</th>
                      <th className="py-2.5 px-3">From / To</th>
                      <th className="py-2.5 px-3">Dep Date & Time</th>
                      <th className="py-2.5 px-3">Class / Status</th>
                      <th className="py-2.5 px-3">Baggage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {flightSegments.map((f, i) => (
                      <tr key={f.id || i} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3 font-semibold text-slate-900">
                          {f.title}
                          <div className="text-[11px] text-slate-500 font-normal">{f.supplierName} (Conf: {f.confirmationRef})</div>
                        </td>
                        <td className="py-3 px-3 font-mono font-bold text-slate-700">
                          {f.origin || 'ORIG'} → {f.destination || 'DEST'}
                        </td>
                        <td className="py-3 px-3 text-slate-600">
                          {f.startDateTime.replace('T', ' ')}
                        </td>
                        <td className="py-3 px-3">
                          <span className="inline-block px-2 py-0.5 bg-emerald-100 text-emerald-800 font-semibold rounded text-[11px]">
                            {f.status.toUpperCase()} (OK)
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-600">
                          2 PC (32kg ea)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Endorsement / Notices */}
          <div className="p-4 bg-sky-50 rounded-lg border border-sky-200 text-xs text-slate-600 space-y-1">
            <p className="font-bold text-slate-800">Endorsements / Restrictions:</p>
            <p className="font-mono text-[11px] text-slate-700">NON-REFUNDABLE / FARE BASIS: J26CORP / VALID ON OPERATING CARRIERS ONLY / NO ROUTING CHANGES AFTER DEPARTURE</p>
            <p className="text-[11px] text-slate-500 pt-1">
              Notice: Carriage and other services provided by the carrier are subject to conditions of carriage, which are hereby incorporated by reference. Passengers on a journey involving an ultimate destination or a stop in a country other than the country of departure are advised that the provisions of international treaties (Montreal Convention / Warsaw Convention) may apply to their entire journey.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
