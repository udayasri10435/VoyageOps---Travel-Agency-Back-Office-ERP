import React, { useState } from 'react';
import { Booking, BookingSegment, BookingStatus } from '../types';
import { formatDate, formatDateTime, formatUSD } from '../utils/formatters';
import {
  X,
  Plane,
  Building,
  Car,
  Compass,
  FileText,
  Printer,
  Tag,
  DollarSign,
  User,
  ShieldCheck,
  AlertTriangle,
  Clock,
  CheckCircle,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { InvoiceModal } from './InvoiceModal';
import { VoucherModal } from './VoucherModal';
import { TicketReceiptModal } from './TicketReceiptModal';

interface BookingDetailModalProps {
  booking: Booking;
  onUpdateStatus: (id: string, status: BookingStatus) => void;
  onUpdateFinancials: (id: string, updates: Partial<Booking['financials']>) => void;
  onClose: () => void;
}

export const BookingDetailModal: React.FC<BookingDetailModalProps> = ({
  booking,
  onUpdateStatus,
  onUpdateFinancials,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'segments' | 'passengers' | 'financials' | 'timeline'>('segments');
  const [showInvoice, setShowInvoice] = useState(false);
  const [showVoucher, setShowVoucher] = useState(false);
  const [selectedVoucherSegment, setSelectedVoucherSegment] = useState<BookingSegment | undefined>(undefined);
  const [showTicketReceipt, setShowTicketReceipt] = useState(false);
  const [copiedPnr, setCopiedPnr] = useState(false);

  const copyPnr = () => {
    navigator.clipboard.writeText(booking.pnrCode);
    setCopiedPnr(true);
    setTimeout(() => setCopiedPnr(false), 2000);
  };

  const getSegmentIcon = (type: string) => {
    switch (type) {
      case 'flight':
        return <Plane className="w-4 h-4 text-sky-400" />;
      case 'hotel':
        return <Building className="w-4 h-4 text-indigo-400" />;
      case 'transfer':
      case 'car_rental':
        return <Car className="w-4 h-4 text-emerald-400" />;
      default:
        return <Compass className="w-4 h-4 text-amber-400" />;
    }
  };

  const getStatusBadge = (status: BookingStatus) => {
    switch (status) {
      case 'ticketed':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'confirmed':
        return 'bg-sky-500/20 text-sky-300 border-sky-500/30';
      case 'invoiced':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      case 'completed':
        return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
      case 'cancelled':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      default:
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
        <div className="bg-slate-900 border border-slate-750 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
          {/* Header */}
          <div className="px-6 py-4 bg-slate-850 border-b border-slate-750 flex-shrink-0">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <button
                  onClick={copyPnr}
                  title="Click to copy PNR"
                  className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 rounded-lg flex items-center space-x-2 text-indigo-300 transition-colors group"
                >
                  <span className="text-xs uppercase tracking-wider text-slate-400">PNR</span>
                  <span className="font-mono font-bold text-base tracking-widest text-indigo-200">{booking.pnrCode}</span>
                  <Copy className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100" />
                </button>
                {copiedPnr && <span className="text-xs text-emerald-400 animate-pulse">Copied!</span>}

                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-bold text-white tracking-tight">{booking.bookingRef}</h2>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full border font-semibold uppercase tracking-wider ${getStatusBadge(
                        booking.status
                      )}`}
                    >
                      {booking.status}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                        booking.type === 'corporate'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {booking.type.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate max-w-md">{booking.title}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2 flex-wrap">
                <button
                  onClick={() => setShowInvoice(true)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 border border-slate-700 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Invoice</span>
                </button>

                <button
                  onClick={() => setShowTicketReceipt(true)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 border border-slate-700 transition-colors"
                >
                  <Plane className="w-3.5 h-3.5 text-sky-400" />
                  <span>E-Ticket</span>
                </button>

                <button
                  onClick={() => {
                    setSelectedVoucherSegment(undefined);
                    setShowVoucher(true);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 border border-slate-700 transition-colors"
                >
                  <Tag className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Voucher</span>
                </button>

                <div className="h-6 w-px bg-slate-700 mx-1" />

                {/* Workflow Status Dropdown */}
                <select
                  value={booking.status}
                  onChange={(e) => onUpdateStatus(booking.id, e.target.value as BookingStatus)}
                  className="bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-medium focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="draft">Draft</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="ticketed">Ticketed</option>
                  <option value="invoiced">Invoiced</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>

                <button
                  onClick={onClose}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Quick Metadata Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-3 border-t border-slate-750/70 text-xs text-slate-300">
              <div>
                <span className="text-slate-500 block text-[11px]">Client / Account:</span>
                <span className="font-semibold text-white">{booking.clientName}</span>
                {booking.corporateCostCenter && (
                  <span className="ml-1 text-[10px] font-mono text-purple-400">({booking.corporateCostCenter})</span>
                )}
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Travel Dates:</span>
                <span>{formatDate(booking.travelStartDate)} – {formatDate(booking.travelEndDate)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Primary Destination:</span>
                <span>{booking.primaryDestination}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Handling Agent:</span>
                <span className="text-indigo-300 font-medium">{booking.agentName}</span>
              </div>
            </div>

            {/* Corporate Policy Alert if any */}
            {booking.travelPolicyCompliance !== 'compliant' && (
              <div className="mt-3 p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center space-x-2 text-xs text-amber-300">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>
                  <strong>Policy Exception:</strong> {booking.policyNotes || 'Approved by corporate travel authority.'}
                </span>
              </div>
            )}
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-750 bg-slate-850/40 px-6">
            <button
              onClick={() => setActiveTab('segments')}
              className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                activeTab === 'segments'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Segments & Services ({booking.segments.length})
            </button>
            <button
              onClick={() => setActiveTab('passengers')}
              className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                activeTab === 'passengers'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Passengers Manifest ({booking.passengers.length})
            </button>
            <button
              onClick={() => setActiveTab('financials')}
              className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                activeTab === 'financials'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Financials & Margin P&L
            </button>
            <button
              onClick={() => setActiveTab('timeline')}
              className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                activeTab === 'timeline'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Audit Trail & GDS History ({booking.timeline.length})
            </button>
          </div>

          {/* Tab Content */}
          <div className="p-6 overflow-y-auto flex-1 space-y-6 text-sm">
            {activeTab === 'segments' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Itinerary Segments (Coupons / Service Lines)</span>
                  <span>Total Gross Value: <strong className="text-emerald-400 font-mono">{formatUSD(booking.financials.totalGrossAmount)}</strong></span>
                </div>

                <div className="space-y-3">
                  {booking.segments.map((seg, idx) => (
                    <div
                      key={seg.id || idx}
                      className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/80 hover:border-slate-600 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-700 mt-0.5">
                            {getSegmentIcon(seg.type)}
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h4 className="font-bold text-white text-sm">{seg.title}</h4>
                              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-700 text-slate-300">
                                {seg.type}
                              </span>
                              <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                {seg.status}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-1">{seg.description}</p>
                            <div className="flex items-center space-x-4 mt-2 text-xs text-slate-500">
                              <span>Supplier: <strong className="text-slate-300">{seg.supplierName}</strong></span>
                              <span>Confirmation: <strong className="font-mono text-indigo-300">{seg.confirmationRef}</strong></span>
                              <span>Date: <strong className="text-slate-300">{formatDate(seg.startDateTime)}</strong></span>
                            </div>
                          </div>
                        </div>

                        {/* Segment Pricing & Voucher Action */}
                        <div className="text-right flex flex-col items-end space-y-2">
                          <div>
                            <span className="text-[11px] text-slate-500 block">Gross Sell Price</span>
                            <span className="text-base font-bold font-mono text-emerald-400">
                              {formatUSD(seg.grossAmount)}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            Net: {formatUSD(seg.netCost)} • Comm: {seg.commissionRate}% ({formatUSD(seg.commissionAmount)})
                          </div>
                          <button
                            onClick={() => {
                              setSelectedVoucherSegment(seg);
                              setShowVoucher(true);
                            }}
                            className="px-2 py-1 bg-slate-700/60 hover:bg-slate-700 text-emerald-300 rounded text-[11px] flex items-center space-x-1"
                          >
                            <Tag className="w-3 h-3" />
                            <span>Service Voucher</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'passengers' && (
              <div className="space-y-4">
                <div className="text-xs text-slate-400">
                  Guest Profiles, Passports & Travel Preferences for this PNR
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {booking.passengers.map((pax, idx) => (
                    <div key={pax.id || idx} className="p-4 bg-slate-800/60 rounded-xl border border-slate-700 space-y-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold text-sm">
                          {pax.firstName[0]}{pax.lastName[0]}
                        </div>
                        <div>
                          <h4 className="font-bold text-white text-sm">
                            {pax.title} {pax.firstName} {pax.lastName}
                          </h4>
                          <p className="text-xs text-slate-400">{pax.email} • {pax.phone}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs bg-slate-900/60 p-3 rounded-lg border border-slate-750">
                        <div>
                          <span className="text-slate-500 block text-[10px] uppercase">Passport Number</span>
                          <span className="font-mono text-slate-200">{pax.passportNumber || 'ON FILE (Secure)'}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px] uppercase">Passport Expiry</span>
                          <span className="text-slate-200">{formatDate(pax.passportExpiry)}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px] uppercase">Nationality</span>
                          <span className="text-slate-200">{pax.nationality}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px] uppercase">Frequent Flyer / Tier</span>
                          <span className="text-indigo-300 font-mono text-[11px]">{pax.frequentFlyer || 'None'}</span>
                        </div>
                      </div>

                      {pax.specialRequests && (
                        <div className="text-xs text-amber-300 bg-amber-500/10 p-2 rounded border border-amber-500/20">
                          <strong>Preferences & Dietary:</strong> {pax.specialRequests}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'financials' && (
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <span className="text-xs text-slate-400 block">Total Net Cost</span>
                    <span className="text-xl font-bold font-mono text-amber-400">
                      {formatUSD(booking.financials.totalNetCost)}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1">Supplier wholesale cost</span>
                  </div>

                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <span className="text-xs text-slate-400 block">Total Gross Invoiced</span>
                    <span className="text-xl font-bold font-mono text-emerald-400">
                      {formatUSD(booking.financials.totalGrossAmount)}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1">Client total billable</span>
                  </div>

                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <span className="text-xs text-slate-400 block">Agency Net Profit</span>
                    <span className="text-xl font-bold font-mono text-indigo-400">
                      {formatUSD(booking.financials.agencyNetProfit)}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      Markup + Retained Comm ({booking.financials.markupPercentage}% markup)
                    </span>
                  </div>

                  <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700">
                    <span className="text-xs text-slate-400 block">Agent Commission Share</span>
                    <span className="text-xl font-bold font-mono text-sky-400">
                      {formatUSD(booking.financials.agentCommissionShare)}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1">
                      {booking.financials.agentSplitRate}% split to {booking.agentName}
                    </span>
                  </div>
                </div>

                {/* Settlement States & Toggles */}
                <div className="p-5 bg-slate-800/40 rounded-xl border border-slate-750 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Accounts Receivable & Payable Status
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-700 flex items-center justify-between">
                      <div>
                        <span className="text-xs text-slate-400 block">Client Billing / Invoice</span>
                        <span className="font-semibold text-white capitalize">{booking.financials.invoiceStatus.replace('_', ' ')}</span>
                      </div>
                      <div className="flex space-x-1.5">
                        <button
                          onClick={() => onUpdateFinancials(booking.id, { invoiceStatus: 'invoiced' })}
                          className={`px-2.5 py-1 text-xs rounded font-medium ${
                            booking.financials.invoiceStatus === 'invoiced'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          Invoiced
                        </button>
                        <button
                          onClick={() => onUpdateFinancials(booking.id, { invoiceStatus: 'paid' })}
                          className={`px-2.5 py-1 text-xs rounded font-medium ${
                            booking.financials.invoiceStatus === 'paid'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          Mark Paid
                        </button>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-700 flex items-center justify-between">
                      <div>
                        <span className="text-xs text-slate-400 block">Supplier Disbursement Status</span>
                        <span className="font-semibold text-white capitalize">{booking.financials.supplierPaymentStatus}</span>
                      </div>
                      <div className="flex space-x-1.5">
                        <button
                          onClick={() => onUpdateFinancials(booking.id, { supplierPaymentStatus: 'authorized' })}
                          className={`px-2.5 py-1 text-xs rounded font-medium ${
                            booking.financials.supplierPaymentStatus === 'authorized'
                              ? 'bg-sky-600 text-white'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          Authorize
                        </button>
                        <button
                          onClick={() => onUpdateFinancials(booking.id, { supplierPaymentStatus: 'settled' })}
                          className={`px-2.5 py-1 text-xs rounded font-medium ${
                            booking.financials.supplierPaymentStatus === 'settled'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          Settled
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'timeline' && (
              <div className="space-y-4">
                <div className="text-xs text-slate-400">
                  GDS & Back-Office Audit History for Record {booking.pnrCode}
                </div>
                <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-750">
                  {booking.timeline.map((evt) => (
                    <div key={evt.id} className="relative">
                      <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-slate-900" />
                      <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-white text-xs">{evt.action}</span>
                          <span className="text-[11px] text-slate-500">{evt.timestamp}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{evt.note}</p>
                        <span className="text-[10px] text-indigo-400 font-medium block mt-1">Actor: {evt.actor}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Embedded Document Modals */}
      {showInvoice && <InvoiceModal booking={booking} onClose={() => setShowInvoice(false)} />}
      {showVoucher && (
        <VoucherModal
          booking={booking}
          segment={selectedVoucherSegment}
          onClose={() => setShowVoucher(false)}
        />
      )}
      {showTicketReceipt && (
        <TicketReceiptModal booking={booking} onClose={() => setShowTicketReceipt(false)} />
      )}
    </>
  );
};
