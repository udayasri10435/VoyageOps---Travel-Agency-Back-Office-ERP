import React, { useState } from 'react';
import { CorporateAccount } from '../types';
import { formatUSD } from '../utils/formatters';
import {
  Building2,
  ShieldCheck,
  CreditCard,
  Users,
  CheckCircle,
  AlertTriangle,
  Plus,
  Sliders,
  Sparkles,
  X,
} from 'lucide-react';

interface CorporateAccountsViewProps {
  corporateAccounts: CorporateAccount[];
  onAddCorporateAccount: (account: CorporateAccount) => void;
  onUpdatePolicy: (id: string, policy: CorporateAccount['travelPolicy']) => void;
}

export const CorporateAccountsView: React.FC<CorporateAccountsViewProps> = ({
  corporateAccounts,
  onAddCorporateAccount,
  onUpdatePolicy,
}) => {
  const [selectedCorpId, setSelectedCorpId] = useState(corporateAccounts[0]?.id || '');
  const [showAddModal, setShowAddModal] = useState(false);

  // Policy Simulator Test State
  const [simHotelRate, setSimHotelRate] = useState<number>(350);
  const [simFlightClass, setSimFlightClass] = useState<'Economy' | 'Premium Economy' | 'Business' | 'First'>('Business');
  const [simTripTotal, setSimTripTotal] = useState<number>(4000);

  // New Corp Account State
  const [newCompanyName, setNewCompanyName] = useState('');
  const [newIndustry, setNewIndustry] = useState('');
  const [newAccountManager, setNewAccountManager] = useState('Marcus Vance');
  const [newBillingEmail, setNewBillingEmail] = useState('');
  const [newCreditLimit, setNewCreditLimit] = useState(150000);

  const activeCorp = corporateAccounts.find((c) => c.id === selectedCorpId) || corporateAccounts[0];

  // Simulator results
  const hotelExceeded = activeCorp ? simHotelRate > activeCorp.travelPolicy.maxHotelDailyRateUSD : false;
  const totalExceeded = activeCorp ? simTripTotal > activeCorp.travelPolicy.requireApprovalAboveUSD : false;
  const flightExceeded = activeCorp
    ? (activeCorp.travelPolicy.maxIntlFlightClass === 'Economy' && simFlightClass !== 'Economy') ||
      (activeCorp.travelPolicy.maxIntlFlightClass === 'Premium Economy' && (simFlightClass === 'Business' || simFlightClass === 'First')) ||
      (activeCorp.travelPolicy.maxIntlFlightClass === 'Business' && simFlightClass === 'First')
    : false;

  const isCompliant = !hotelExceeded && !totalExceeded && !flightExceeded;

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const newAcc: CorporateAccount = {
      id: 'corp-' + Date.now(),
      companyName: newCompanyName,
      industry: newIndustry || 'Commercial Enterprise',
      accountManager: newAccountManager,
      billingEmail: newBillingEmail,
      creditLimit: newCreditLimit,
      paymentTerms: 'Net 30 days',
      contractDiscount: 8.0,
      activeTravelersCount: 15,
      totalSpendYTD: 0,
      travelPolicy: {
        maxHotelDailyRateUSD: 350,
        maxDomesticFlightClass: 'Economy',
        maxIntlFlightClass: 'Business',
        requireApprovalAboveUSD: 4000,
        preferredSuppliers: ['Singapore Airlines', 'Marriott International'],
      },
    };
    onAddCorporateAccount(newAcc);
    setSelectedCorpId(newAcc.id);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-850 p-4 rounded-xl border border-slate-750">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">Corporate Accounts & Travel Policy Hub</h2>
          <p className="text-xs text-slate-400">Configure corporate booking rules, hotel rate caps, approval thresholds, and preferred consortia</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm transition-colors whitespace-nowrap self-start md:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Corporate Account</span>
        </button>
      </div>

      {/* Account Selector Tabs */}
      <div className="flex items-center space-x-3 overflow-x-auto pb-1 text-xs">
        {corporateAccounts.map((corp) => (
          <button
            key={corp.id}
            onClick={() => setSelectedCorpId(corp.id)}
            className={`px-4 py-2 rounded-xl font-bold transition-all flex items-center space-x-2 whitespace-nowrap ${
              selectedCorpId === corp.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'bg-slate-850 text-slate-400 hover:text-white border border-slate-750'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>{corp.companyName}</span>
          </button>
        ))}
      </div>

      {/* Corporate Account Details */}
      {activeCorp && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Account Profile & Spend */}
          <div className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-5">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">Company Profile</span>
              <h3 className="text-xl font-bold text-white mt-1">{activeCorp.companyName}</h3>
              <p className="text-xs text-slate-400">{activeCorp.industry}</p>
            </div>

            <div className="space-y-3 text-xs bg-slate-900/60 p-4 rounded-xl border border-slate-750">
              <div className="flex justify-between">
                <span className="text-slate-400">Account Manager:</span>
                <span className="font-semibold text-slate-200">{activeCorp.accountManager}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Billing Email:</span>
                <span className="text-slate-200 font-mono text-[11px]">{activeCorp.billingEmail}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Payment Terms:</span>
                <span className="font-semibold text-indigo-300">{activeCorp.paymentTerms}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Contract Discount:</span>
                <span className="font-semibold text-emerald-400">{activeCorp.contractDiscount}% off published</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-750">
                <span className="text-[11px] text-slate-500 uppercase block">Credit Facility</span>
                <span className="font-mono text-base font-bold text-white">{formatUSD(activeCorp.creditLimit)}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-750">
                <span className="text-[11px] text-slate-500 uppercase block">YTD Total Spend</span>
                <span className="font-mono text-base font-bold text-emerald-400">{formatUSD(activeCorp.totalSpendYTD)}</span>
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase block mb-2">Preferred Suppliers</span>
              <div className="flex flex-wrap gap-1.5">
                {activeCorp.travelPolicy.preferredSuppliers.map((sup, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 bg-slate-800 text-slate-300 rounded-md text-xs border border-slate-700 font-medium"
                  >
                    {sup}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Travel Policy Rules Configuration */}
          <div className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-5">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-white">Active Corporate Travel Policy</h3>
            </div>
            <p className="text-xs text-slate-400">
              Rules enforced during PNR creation and agent booking validation.
            </p>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Max Hotel Daily Room Rate ($)</label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    value={activeCorp.travelPolicy.maxHotelDailyRateUSD}
                    onChange={(e) =>
                      onUpdatePolicy(activeCorp.id, {
                        ...activeCorp.travelPolicy,
                        maxHotelDailyRateUSD: Number(e.target.value),
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                  <span className="p-2 text-slate-500">/ night</span>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Max Domestic Flight Cabin Class</label>
                <select
                  value={activeCorp.travelPolicy.maxDomesticFlightClass}
                  onChange={(e) =>
                    onUpdatePolicy(activeCorp.id, {
                      ...activeCorp.travelPolicy,
                      maxDomesticFlightClass: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                >
                  <option value="Economy">Economy</option>
                  <option value="Premium Economy">Premium Economy</option>
                  <option value="Business">Business</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Max International Flight Cabin Class</label>
                <select
                  value={activeCorp.travelPolicy.maxIntlFlightClass}
                  onChange={(e) =>
                    onUpdatePolicy(activeCorp.id, {
                      ...activeCorp.travelPolicy,
                      maxIntlFlightClass: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                >
                  <option value="Economy">Economy</option>
                  <option value="Premium Economy">Premium Economy</option>
                  <option value="Business">Business</option>
                  <option value="First">First Class</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Pre-Trip Manager Approval Threshold ($)</label>
                <input
                  type="number"
                  value={activeCorp.travelPolicy.requireApprovalAboveUSD}
                  onChange={(e) =>
                    onUpdatePolicy(activeCorp.id, {
                      ...activeCorp.travelPolicy,
                      requireApprovalAboveUSD: Number(e.target.value),
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Policy Compliance Simulator */}
          <div className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-5">
            <div className="flex items-center space-x-2">
              <Sliders className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-white">Policy Compliance Simulator</h3>
            </div>
            <p className="text-xs text-slate-400">
              Test hypothetical booking parameters against {activeCorp.companyName} rules in real-time.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Proposed Hotel Rate ($/nt)</label>
                <input
                  type="number"
                  value={simHotelRate}
                  onChange={(e) => setSimHotelRate(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Flight Cabin Class</label>
                <select
                  value={simFlightClass}
                  onChange={(e) => setSimFlightClass(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                >
                  <option value="Economy">Economy</option>
                  <option value="Premium Economy">Premium Economy</option>
                  <option value="Business">Business</option>
                  <option value="First">First</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Total Trip Budget ($)</label>
                <input
                  type="number"
                  value={simTripTotal}
                  onChange={(e) => setSimTripTotal(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {/* Test Verdict */}
            <div
              className={`p-4 rounded-xl border text-xs space-y-2 ${
                isCompliant
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="flex items-center space-x-2 font-bold text-sm">
                {isCompliant ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span>Booking is 100% Policy Compliant</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <span>Requires Policy Exception Review</span>
                  </>
                )}
              </div>

              <div className="space-y-1 text-[11px] text-slate-300 pt-1">
                {hotelExceeded && (
                  <p>• Hotel rate (${simHotelRate}) exceeds ${activeCorp.travelPolicy.maxHotelDailyRateUSD} limit.</p>
                )}
                {flightExceeded && (
                  <p>• Flight class ({simFlightClass}) exceeds allowed class ({activeCorp.travelPolicy.maxIntlFlightClass}).</p>
                )}
                {totalExceeded && (
                  <p>• Trip spend (${simTripTotal}) triggers pre-trip approval threshold (${activeCorp.travelPolicy.requireApprovalAboveUSD}).</p>
                )}
                {isCompliant && <p>• All segments pass corporate benchmarks for auto-ticketing.</p>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Corporate Account Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-750 pb-3">
              <h3 className="text-base font-bold text-white">Add Corporate Client Account</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Company Legal Name *</label>
                <input
                  type="text"
                  required
                  value={newCompanyName}
                  onChange={(e) => setNewCompanyName(e.target.value)}
                  placeholder="e.g. Acme Global Logistics"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Industry</label>
                <input
                  type="text"
                  value={newIndustry}
                  onChange={(e) => setNewIndustry(e.target.value)}
                  placeholder="e.g. Fintech / Technology"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Billing Email *</label>
                <input
                  type="email"
                  required
                  value={newBillingEmail}
                  onChange={(e) => setNewBillingEmail(e.target.value)}
                  placeholder="ap-travel@company.com"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Credit Limit ($)</label>
                <input
                  type="number"
                  value={newCreditLimit}
                  onChange={(e) => setNewCreditLimit(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-750">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold shadow-sm"
                >
                  Save Corporate Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
