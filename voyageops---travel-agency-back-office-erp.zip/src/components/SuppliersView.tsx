import React, { useState } from 'react';
import { Supplier, SupplierCategory } from '../types';
import { formatUSD } from '../utils/formatters';
import {
  Building2,
  Plane,
  Building,
  Car,
  Compass,
  Train,
  Plus,
  Search,
  Star,
  Phone,
  Mail,
  CreditCard,
  X,
  CheckCircle,
} from 'lucide-react';

interface SuppliersViewProps {
  suppliers: Supplier[];
  onAddSupplier: (supplier: Supplier) => void;
}

export const SuppliersView: React.FC<SuppliersViewProps> = ({ suppliers, onAddSupplier }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Supplier Form State
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState<SupplierCategory>('airline');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contractType, setContractType] = useState<Supplier['contractType']>('direct_contract');
  const [defaultCommissionRate, setDefaultCommissionRate] = useState<number>(8.0);
  const [paymentTerms, setPaymentTerms] = useState<Supplier['paymentTerms']>('net_30');
  const [creditLimit, setCreditLimit] = useState<number>(50000);
  const [gdsOfficeId, setGdsOfficeId] = useState('');
  const [notes, setNotes] = useState('');

  const filteredSuppliers = suppliers.filter((sup) => {
    const matchesCat = selectedCategory === 'all' || sup.category === selectedCategory;
    const matchesQuery =
      sup.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sup.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sup.contactName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  const getCategoryIcon = (cat: SupplierCategory) => {
    switch (cat) {
      case 'airline':
        return <Plane className="w-4 h-4 text-sky-400" />;
      case 'hotel_chain':
        return <Building className="w-4 h-4 text-indigo-400" />;
      case 'dmc':
        return <Compass className="w-4 h-4 text-emerald-400" />;
      case 'car_rental':
        return <Car className="w-4 h-4 text-amber-400" />;
      case 'rail':
        return <Train className="w-4 h-4 text-rose-400" />;
      default:
        return <Building2 className="w-4 h-4 text-slate-400" />;
    }
  };

  const handleCreateSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    const newSup: Supplier = {
      id: 'sup-' + Date.now(),
      code: code.toUpperCase().trim() || 'SUP',
      name,
      category,
      contactName,
      contactEmail,
      contactPhone,
      contractType,
      defaultCommissionRate,
      paymentTerms,
      creditLimit,
      balancePayable: 0,
      rating: 4.8,
      activeContractsCount: 1,
      gdsOfficeId: gdsOfficeId || undefined,
      notes,
    };
    onAddSupplier(newSup);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-850 p-4 rounded-xl border border-slate-750">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">Supplier & Contract Management</h2>
          <p className="text-xs text-slate-400">Direct airline contracts, DMC ground operators, hotel consortia, and GDS desks</p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by code, supplier, contact..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:ring-1 focus:ring-indigo-500 w-64"
            />
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Supplier</span>
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'all', label: 'All Suppliers' },
          { id: 'airline', label: 'Airlines (GDS/NDC)' },
          { id: 'hotel_chain', label: 'Hotels & Consortia' },
          { id: 'dmc', label: 'DMCs & Ground Operators' },
          { id: 'car_rental', label: 'Car Rental Fleets' },
          { id: 'rail', label: 'Rail Operators' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap ${
              selectedCategory === tab.id
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-850 text-slate-400 hover:text-slate-200 border border-slate-750'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSuppliers.map((sup) => (
          <div
            key={sup.id}
            className="bg-slate-850 rounded-xl border border-slate-750 p-5 flex flex-col justify-between hover:border-slate-650 transition-all shadow-sm"
          >
            <div>
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-750">
                    {getCategoryIcon(sup.category)}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm tracking-tight">{sup.name}</h3>
                    <div className="flex items-center space-x-2 mt-0.5">
                      <span className="font-mono text-[11px] font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded">
                        {sup.code}
                      </span>
                      <span className="text-[11px] text-slate-400 capitalize">
                        {sup.category.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-1 text-amber-400 text-xs font-bold bg-amber-500/10 px-2 py-0.5 rounded">
                  <Star className="w-3 h-3 fill-amber-400" />
                  <span>{sup.rating}</span>
                </div>
              </div>

              {/* Contract Terms & Rates */}
              <div className="grid grid-cols-2 gap-2 mt-4 p-3 bg-slate-900/70 rounded-lg border border-slate-750 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Commission Yield</span>
                  <span className="font-mono font-bold text-emerald-400">{sup.defaultCommissionRate}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Payment Terms</span>
                  <span className="font-mono text-slate-200 uppercase">{sup.paymentTerms.replace('_', ' ')}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Contract Channel</span>
                  <span className="text-slate-300 text-[11px]">{sup.contractType.replace('_', ' ')}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Payable Balance</span>
                  <span className="font-mono font-bold text-amber-400">{formatUSD(sup.balancePayable)}</span>
                </div>
              </div>

              {/* Contact Info */}
              <div className="mt-4 space-y-1.5 text-xs text-slate-400">
                <div className="flex items-center space-x-2">
                  <Mail className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                  <span className="truncate">{sup.contactEmail}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                  <span>{sup.contactPhone}</span>
                </div>
                {sup.gdsOfficeId && (
                  <div className="text-[11px] text-slate-500">
                    GDS Terminal / Office ID: <span className="font-mono text-indigo-400">{sup.gdsOfficeId}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Footer notes */}
            {sup.notes && (
              <div className="mt-4 pt-3 border-t border-slate-750/70 text-[11px] text-slate-400 italic">
                "{sup.notes}"
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add Supplier Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-750 pb-3">
              <h3 className="text-base font-bold text-white">Add New Supplier or Consortia</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="text-slate-400 block mb-1">Supplier Commercial Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Cathay Pacific Airways"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Code / IATA Prefix *</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="e.g. CX"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as SupplierCategory)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="airline">Airline</option>
                    <option value="hotel_chain">Hotel Chain</option>
                    <option value="dmc">DMC / Ground</option>
                    <option value="car_rental">Car Rental</option>
                    <option value="rail">Rail Operator</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Contract Channel</label>
                  <select
                    value={contractType}
                    onChange={(e) => setContractType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="direct_contract">Direct Contract</option>
                    <option value="gds_amadeus">GDS Amadeus</option>
                    <option value="gds_sabre">GDS Sabre</option>
                    <option value="wholesaler">Wholesaler / Bedbank</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Default Commission %</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    max="100"
                    value={defaultCommissionRate}
                    onChange={(e) => setDefaultCommissionRate(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Primary Contact Name</label>
                  <input
                    type="text"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="Account Director"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Contact Email *</label>
                  <input
                    type="email"
                    required
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-slate-400 block mb-1">Payment Terms</label>
                  <select
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="net_7">Net 7 Days</option>
                    <option value="net_15">Net 15 Days</option>
                    <option value="net_30">Net 30 Days</option>
                    <option value="prepaid">Prepaid</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Credit Facility Limit ($)</label>
                  <input
                    type="number"
                    min="0"
                    value={creditLimit}
                    onChange={(e) => setCreditLimit(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">GDS Office / PCC</label>
                  <input
                    type="text"
                    value={gdsOfficeId}
                    onChange={(e) => setGdsOfficeId(e.target.value)}
                    placeholder="e.g. SFO1A002"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Agreement Notes / Override Details</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Tier targets, cancellation waivers, or direct API credentials..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-750">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold shadow-sm"
                >
                  Save Supplier Contract
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
