import React from 'react';
import { Booking } from '../types';
import { formatUSD, formatDate } from '../utils/formatters';
import { Printer, X, Download, Building2, CheckCircle2, ShieldCheck } from 'lucide-react';

interface InvoiceModalProps {
  booking: Booking;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ booking, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const invoiceNumber = `INV-${booking.bookingRef.replace('VO-', '2026-')}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Controls (Hidden in Print) */}
        <div className="print:hidden flex items-center justify-between px-6 py-4 bg-slate-800/80 border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center justify-center p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Building2 className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-semibold text-white">Commercial Tax Invoice</h3>
              <p className="text-xs text-slate-400">{invoiceNumber} • {booking.clientName}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Container */}
        <div className="p-8 md:p-12 bg-white text-slate-900 print:p-0 print:m-0 print:w-full" id="printable-invoice">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-8">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-lg">
                  V
                </div>
                <span className="text-2xl font-extrabold tracking-tight text-slate-900">VOYAGE<span className="text-indigo-600">OPS</span></span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Enterprise Travel Management & Back-Office ERP</p>
              <p className="text-xs text-slate-500">IATA Accredited Agency #05-892102</p>
              <p className="text-xs text-slate-500">Suite 1400, Financial Tower, San Francisco, CA</p>
              <p className="text-xs text-slate-500">billing@voyageops-global.com | +1 (800) 555-8920</p>
            </div>

            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-md text-xs font-semibold uppercase tracking-wider mb-2">
                {booking.financials.invoiceStatus.toUpperCase()}
              </span>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{invoiceNumber}</h1>
              <p className="text-xs text-slate-500 mt-1">Invoice Date: {formatDate(new Date().toISOString())}</p>
              <p className="text-xs text-slate-500">PNR Reference: <span className="font-mono font-bold text-slate-800">{booking.pnrCode}</span></p>
              <p className="text-xs text-slate-500">Booking Ref: <span className="font-mono text-slate-800">{booking.bookingRef}</span></p>
            </div>
          </div>

          {/* Client & Billing Details */}
          <div className="grid grid-cols-2 gap-8 py-6 border-b border-slate-200 text-sm">
            <div>
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Billed To:</h4>
              <p className="font-bold text-slate-800 text-base">{booking.clientName}</p>
              <p className="text-slate-600">{booking.clientEmail}</p>
              <p className="text-slate-600">{booking.clientPhone}</p>
              {booking.corporateCostCenter && (
                <div className="mt-2 inline-flex items-center px-2.5 py-1 bg-slate-100 rounded text-xs text-slate-700 font-mono">
                  Cost Center: <strong className="ml-1 text-slate-900">{booking.corporateCostCenter}</strong>
                </div>
              )}
            </div>

            <div className="text-right">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Trip Summary:</h4>
              <p className="font-medium text-slate-800">{booking.title}</p>
              <p className="text-slate-600">{booking.primaryDestination}</p>
              <p className="text-slate-600">Travel Period: {formatDate(booking.travelStartDate)} – {formatDate(booking.travelEndDate)}</p>
              <p className="text-slate-500 text-xs mt-1">Lead Agent: {booking.agentName}</p>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="py-6">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Itemized Travel Services</h4>
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-xs uppercase">
                  <th className="py-2.5">Service Description</th>
                  <th className="py-2.5">Supplier / Conf #</th>
                  <th className="py-2.5">Type</th>
                  <th className="py-2.5 text-right">Amount (USD)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {booking.segments.map((seg, idx) => (
                  <tr key={seg.id || idx}>
                    <td className="py-3 pr-4">
                      <p className="font-semibold text-slate-800">{seg.title}</p>
                      <p className="text-xs text-slate-500">{seg.description}</p>
                    </td>
                    <td className="py-3 text-slate-600 text-xs">
                      <div>{seg.supplierName}</div>
                      <div className="font-mono text-slate-400">{seg.confirmationRef}</div>
                    </td>
                    <td className="py-3 text-slate-600 text-xs capitalize">
                      {seg.type}
                    </td>
                    <td className="py-3 text-right font-mono font-medium text-slate-800">
                      {formatUSD(seg.grossAmount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end pt-4 border-t border-slate-200">
            <div className="w-72 space-y-2 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal (Net + Service):</span>
                <span className="font-mono">{formatUSD(booking.financials.totalGrossAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Applicable Taxes & Fees (Included):</span>
                <span className="font-mono">$0.00</span>
              </div>
              <div className="flex justify-between text-base font-bold text-slate-900 pt-3 border-t border-slate-200">
                <span>Total Due:</span>
                <span className="font-mono text-indigo-600 text-lg">{formatUSD(booking.financials.totalGrossAmount)}</span>
              </div>
            </div>
          </div>

          {/* Payment Terms & Instructions */}
          <div className="mt-8 pt-6 border-t border-slate-200 grid grid-cols-2 gap-6 text-xs text-slate-500">
            <div>
              <p className="font-semibold text-slate-700 mb-1">Payment Instructions:</p>
              <p>Bank: JPMorgan Chase NA (New York)</p>
              <p>Account Name: VoyageOps Global Travel Solutions LLC</p>
              <p>Routing (ABA): 021000021 • Account: 884-2910-4491</p>
              <p>SWIFT/BIC: CHASUS33XXX</p>
            </div>
            <div>
              <p className="font-semibold text-slate-700 mb-1">Corporate Terms:</p>
              <p>Payment due in full within 30 days of invoice date. Unbilled modifications and itinerary changes subject to airline fare rule recalculations.</p>
              <p className="mt-2 text-emerald-600 flex items-center font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Authorized Back-Office Document
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
