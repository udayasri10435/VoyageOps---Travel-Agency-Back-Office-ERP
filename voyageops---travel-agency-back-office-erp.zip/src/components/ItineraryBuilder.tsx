import React, { useState } from 'react';
import { Itinerary, ItineraryDay, ItineraryItem, Booking, SegmentType } from '../types';
import { formatUSD, formatDate, generatePNR, generateBookingRef } from '../utils/formatters';
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  MapPin,
  Plane,
  Building,
  Car,
  Compass,
  Briefcase,
  Printer,
  Sparkles,
  CheckCircle,
  Eye,
  FileCheck,
  ChevronRight,
  Send,
  Layers,
  Edit3
} from 'lucide-react';

interface ItineraryBuilderProps {
  itineraries: Itinerary[];
  onSaveItinerary: (itinerary: Itinerary) => void;
  onConvertToBooking: (booking: Booking) => void;
}

export const ItineraryBuilder: React.FC<ItineraryBuilderProps> = ({
  itineraries,
  onSaveItinerary,
  onConvertToBooking,
}) => {
  const [selectedItineraryId, setSelectedItineraryId] = useState<string>(itineraries[0]?.id || '');
  const [isEditing, setIsEditing] = useState(false);
  const [proposalMode, setProposalMode] = useState(false);

  // Active itinerary
  const activeItinerary = itineraries.find((it) => it.id === selectedItineraryId) || itineraries[0];

  // Editable state
  const [formData, setFormData] = useState<Itinerary>(activeItinerary);

  const handleSelectItinerary = (it: Itinerary) => {
    setSelectedItineraryId(it.id);
    setFormData(it);
    setIsEditing(false);
    setProposalMode(false);
  };

  const handleStartCreate = () => {
    const newItin: Itinerary = {
      id: 'itin-' + Date.now(),
      title: 'New Bespoke Itinerary',
      clientName: 'VIP Client / Corporate Account',
      clientEmail: 'traveler@company.com',
      tripType: 'leisure',
      destination: 'Paris & French Riviera',
      startDate: '2026-10-15',
      endDate: '2026-10-22',
      heroImage: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80',
      overview: 'Curated premium itinerary featuring five-star luxury accommodation and private door-to-door concierge transfers.',
      days: [
        {
          dayNumber: 1,
          date: '2026-10-15',
          title: 'Arrival & Welcome Dinner',
          description: 'VIP meet at the airport and private transfer to hotel.',
          items: [
            {
              id: 'item-' + Date.now(),
              time: '14:00',
              type: 'hotel',
              title: 'Check-in: Luxury Hotel',
              location: 'City Center',
              description: 'Deluxe suite with breakfast included.',
              confirmationNumber: 'HTL-8910',
            },
          ],
        },
      ],
      inclusions: ['Private airport chauffeur transfers', 'Daily complimentary luxury breakfast', 'Concierge assistance 24/7'],
      exclusions: ['International airfare (unless specified)', 'Gratuities & personal incidentals'],
      totalCostEstimate: 5000,
      recommendedSellingPrice: 6200,
      targetMarginPercent: 24.0,
      status: 'draft',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setFormData(newItin);
    setIsEditing(true);
    setProposalMode(false);
  };

  const handleAddDay = () => {
    const nextDayNum = formData.days.length + 1;
    const newDay: ItineraryDay = {
      dayNumber: nextDayNum,
      date: '2026-10-' + (15 + nextDayNum - 1),
      title: `Day ${nextDayNum} Exploration`,
      description: 'Scheduled activities and private appointments.',
      items: [
        {
          id: 'item-' + Date.now(),
          time: '10:00',
          type: 'activity',
          title: 'Private Guided Cultural Tour',
          location: 'City Center',
          description: 'Exclusive after-hours access with private curator.',
        },
      ],
    };

    setFormData({
      ...formData,
      days: [...formData.days, newDay],
    });
  };

  const handleRemoveDay = (dayIndex: number) => {
    const updated = formData.days.filter((_, i) => i !== dayIndex);
    // reindex
    const reindexed = updated.map((d, i) => ({ ...d, dayNumber: i + 1 }));
    setFormData({ ...formData, days: reindexed });
  };

  const handleAddItem = (dayIndex: number, type: SegmentType | 'meeting') => {
    const newItem: ItineraryItem = {
      id: 'item-' + Date.now() + Math.random(),
      time: '12:00',
      type,
      title: `New ${type.toUpperCase()}`,
      location: formData.destination,
      description: 'Details and arrangements.',
      badge: type === 'flight' ? 'Business Class' : undefined,
    };

    const updatedDays = [...formData.days];
    updatedDays[dayIndex].items.push(newItem);
    setFormData({ ...formData, days: updatedDays });
  };

  const handleRemoveItem = (dayIndex: number, itemIndex: number) => {
    const updatedDays = [...formData.days];
    updatedDays[dayIndex].items = updatedDays[dayIndex].items.filter((_, i) => i !== itemIndex);
    setFormData({ ...formData, days: updatedDays });
  };

  const handleSave = () => {
    onSaveItinerary(formData);
    setSelectedItineraryId(formData.id);
    setIsEditing(false);
  };

  // Convert an approved itinerary into an active PNR booking
  const handleConvertToBookingAction = () => {
    const pnr = generatePNR();
    const ref = generateBookingRef();

    // Map itinerary items to booking segments
    const segments = formData.days.flatMap((day) =>
      day.items.map((item, idx) => ({
        id: 'seg-' + Date.now() + idx,
        type: (item.type === 'meeting' ? 'activity' : item.type) as SegmentType,
        supplierId: 'sup-direct',
        supplierName: item.badge || 'Preferred Partner',
        confirmationRef: item.confirmationNumber || 'CONF-' + Math.floor(1000 + Math.random() * 9000),
        title: item.title,
        description: item.description,
        startDateTime: `${day.date}T${item.time}:00`,
        endDateTime: `${day.date}T22:00:00`,
        destination: item.location || formData.destination,
        netCost: Math.round(formData.totalCostEstimate / (formData.days.length * 2 || 1)),
        grossAmount: Math.round(formData.recommendedSellingPrice / (formData.days.length * 2 || 1)),
        commissionRate: 10,
        commissionAmount: Math.round((formData.recommendedSellingPrice / (formData.days.length * 2 || 1)) * 0.1),
        currency: 'USD',
        status: 'confirmed' as const,
      }))
    );

    const newBooking: Booking = {
      id: 'bk-' + Date.now(),
      bookingRef: ref,
      pnrCode: pnr,
      type: formData.tripType === 'corporate' ? 'corporate' : 'leisure',
      title: formData.title,
      clientName: formData.clientName,
      clientEmail: formData.clientEmail,
      clientPhone: '+1 555 019 8820',
      travelPolicyCompliance: 'compliant',
      status: 'confirmed',
      bookingDate: new Date().toISOString().split('T')[0],
      travelStartDate: formData.startDate,
      travelEndDate: formData.endDate,
      primaryDestination: formData.destination,
      passengers: [
        {
          id: 'pax-' + Date.now(),
          title: 'Mr.',
          firstName: formData.clientName.split(' ')[0] || 'Client',
          lastName: formData.clientName.split(' ')[1] || 'Guest',
          email: formData.clientEmail,
          phone: '+1 555 019 8820',
          passportNumber: 'PA' + Math.floor(1000000 + Math.random() * 9000000),
          passportExpiry: '2030-01-01',
          nationality: 'United States',
        },
      ],
      segments: segments.length > 0 ? segments : [
        {
          id: 'seg-1',
          type: 'hotel',
          supplierId: 'sup-direct',
          supplierName: 'Partner Hotel',
          confirmationRef: 'DIR-8810',
          title: formData.title,
          description: formData.overview,
          startDateTime: formData.startDate + 'T14:00:00',
          endDateTime: formData.endDate + 'T11:00:00',
          netCost: formData.totalCostEstimate,
          grossAmount: formData.recommendedSellingPrice,
          commissionRate: 10,
          commissionAmount: formData.recommendedSellingPrice * 0.1,
          currency: 'USD',
          status: 'confirmed',
        },
      ],
      financials: {
        totalNetCost: formData.totalCostEstimate,
        totalGrossAmount: formData.recommendedSellingPrice,
        markupAmount: formData.recommendedSellingPrice - formData.totalCostEstimate,
        markupPercentage: formData.targetMarginPercent,
        totalCommissionEarned: formData.recommendedSellingPrice * 0.1,
        agentSplitRate: 40,
        agentCommissionShare: formData.recommendedSellingPrice * 0.1 * 0.4,
        agencyNetProfit: (formData.recommendedSellingPrice - formData.totalCostEstimate) + (formData.recommendedSellingPrice * 0.1 * 0.6),
        invoiceStatus: 'unbilled',
        supplierPaymentStatus: 'pending',
        currency: 'USD',
      },
      agentId: 'agt-101',
      agentName: 'Marcus Vance',
      internalNotes: `Converted automatically from Itinerary Proposal #${formData.id}`,
      timeline: [
        {
          id: 'ev-conv',
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          actor: 'Itinerary Engine',
          action: 'Itinerary Converted to Confirmed Booking',
          note: `PNR ${pnr} generated. Segments linked.`,
        },
      ],
    };

    onConvertToBooking(newBooking);
  };

  const getItemIcon = (type: string) => {
    switch (type) {
      case 'flight':
        return <Plane className="w-4 h-4 text-sky-400" />;
      case 'hotel':
        return <Building className="w-4 h-4 text-indigo-400" />;
      case 'transfer':
      case 'car_rental':
        return <Car className="w-4 h-4 text-emerald-400" />;
      case 'meeting':
        return <Briefcase className="w-4 h-4 text-purple-400" />;
      default:
        return <Compass className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-header navigation & actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-850 p-4 rounded-xl border border-slate-750">
        <div className="flex items-center space-x-3 overflow-x-auto pb-2 md:pb-0">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Proposals:</span>
          {itineraries.map((it) => (
            <button
              key={it.id}
              onClick={() => handleSelectItinerary(it)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                selectedItineraryId === it.id && !isEditing
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              {it.title.length > 25 ? it.title.substring(0, 25) + '...' : it.title}
            </button>
          ))}
          <button
            onClick={handleStartCreate}
            className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-semibold flex items-center space-x-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Itinerary</span>
          </button>
        </div>

        <div className="flex items-center space-x-2">
          {proposalMode ? (
            <button
              onClick={() => setProposalMode(false)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 border border-slate-700"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Back-Office View</span>
            </button>
          ) : (
            <button
              onClick={() => setProposalMode(true)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Client Proposal Presentation</span>
            </button>
          )}

          {!proposalMode && !isEditing && (
            <button
              onClick={() => {
                setFormData(activeItinerary);
                setIsEditing(true);
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 border border-slate-700"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Plan</span>
            </button>
          )}

          <button
            onClick={handleConvertToBookingAction}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm"
            title="Convert this itinerary directly into a confirmed PNR booking with cost lines"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Convert to Booking PNR</span>
          </button>
        </div>
      </div>

      {/* CLIENT PROPOSAL PRESENTATION VIEW */}
      {proposalMode ? (
        <div className="bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl">
          {/* Printable Proposal Banner */}
          <div className="relative h-64 md:h-80 overflow-hidden">
            <img
              src={activeItinerary.heroImage}
              alt={activeItinerary.title}
              className="w-full h-full object-cover brightness-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <span className="inline-block px-3 py-1 rounded-full bg-indigo-600/80 backdrop-blur-md text-white text-xs font-bold uppercase tracking-wider mb-2">
                  {activeItinerary.tripType.toUpperCase()} TRAVEL PROPOSAL
                </span>
                <h1 className="text-2xl md:text-4xl font-black text-white tracking-tight">{activeItinerary.title}</h1>
                <p className="text-sm text-slate-300 mt-1 flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-indigo-400" />
                  <span>{activeItinerary.destination}</span>
                  <span>•</span>
                  <span>Prepared for: <strong>{activeItinerary.clientName}</strong></span>
                </p>
              </div>
              <div className="text-right bg-slate-900/80 backdrop-blur-md p-4 rounded-xl border border-slate-750">
                <span className="text-xs text-slate-400 block uppercase font-medium">All-Inclusive Total</span>
                <span className="text-2xl font-black font-mono text-emerald-400">
                  {formatUSD(activeItinerary.recommendedSellingPrice)}
                </span>
                <span className="text-[11px] text-slate-400 block">{formatDate(activeItinerary.startDate)} – {formatDate(activeItinerary.endDate)}</span>
              </div>
            </div>
          </div>

          <div className="p-8 space-y-8 max-w-5xl mx-auto">
            {/* Overview */}
            <div className="bg-slate-850 p-6 rounded-xl border border-slate-750">
              <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-2">Executive Summary</h3>
              <p className="text-slate-300 text-sm leading-relaxed">{activeItinerary.overview}</p>
            </div>

            {/* Daily Schedule Timeline */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-white tracking-tight flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-indigo-400" />
                <span>Day-by-Day Journey Schedule</span>
              </h3>

              <div className="space-y-6">
                {activeItinerary.days.map((day) => (
                  <div key={day.dayNumber} className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-750 pb-3">
                      <div className="flex items-center space-x-3">
                        <span className="w-8 h-8 rounded-lg bg-indigo-600 text-white font-bold flex items-center justify-center text-sm">
                          {day.dayNumber}
                        </span>
                        <div>
                          <h4 className="font-bold text-white text-base">{day.title}</h4>
                          <span className="text-xs text-slate-400">{formatDate(day.date)}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-400">{day.description}</p>

                    <div className="space-y-2.5 pt-2">
                      {day.items.map((item) => (
                        <div
                          key={item.id}
                          className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 flex items-start justify-between"
                        >
                          <div className="flex items-start space-x-3">
                            <div className="p-2 bg-slate-800 rounded-md mt-0.5">
                              {getItemIcon(item.type)}
                            </div>
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="font-mono text-xs font-bold text-indigo-400">{item.time}</span>
                                <h5 className="font-semibold text-white text-sm">{item.title}</h5>
                                {item.badge && (
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-indigo-500/30">
                                    {item.badge}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-400 mt-0.5">{item.description}</p>
                              {item.location && (
                                <p className="text-[11px] text-slate-500 mt-1 flex items-center space-x-1">
                                  <MapPin className="w-3 h-3" />
                                  <span>{item.location}</span>
                                </p>
                              )}
                            </div>
                          </div>

                          {item.confirmationNumber && (
                            <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2 py-1 rounded">
                              {item.confirmationNumber}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Inclusions & Exclusions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-850 p-6 rounded-xl border border-emerald-500/20">
                <h4 className="font-bold text-emerald-400 text-sm mb-3 flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>Program Inclusions</span>
                </h4>
                <ul className="space-y-2 text-xs text-slate-300">
                  {activeItinerary.inclusions.map((inc, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{inc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-850 p-6 rounded-xl border border-slate-750">
                <h4 className="font-bold text-slate-400 text-sm mb-3">Exclusions & Policy Notes</h4>
                <ul className="space-y-2 text-xs text-slate-400">
                  {activeItinerary.exclusions.map((exc, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <span className="text-slate-500 font-bold">•</span>
                      <span>{exc}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      ) : isEditing ? (
        /* EDITING MODE */
        <div className="bg-slate-900 border border-slate-750 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-750 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white">Interactive Itinerary & Proposal Editor</h2>
              <p className="text-xs text-slate-400">Construct day-by-day schedules with live cost & margin calculation</p>
            </div>
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-sm"
              >
                Save Itinerary
              </button>
            </div>
          </div>

          {/* Form Fields */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Itinerary Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Client Name / Account *</label>
              <input
                type="text"
                value={formData.clientName}
                onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Trip Category</label>
              <select
                value={formData.tripType}
                onChange={(e) => setFormData({ ...formData, tripType: e.target.value as any })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              >
                <option value="corporate">Corporate</option>
                <option value="leisure">Leisure</option>
                <option value="bleisure">Bleisure</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Destination</label>
              <input
                type="text"
                value={formData.destination}
                onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Start Date</label>
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">End Date</label>
              <input
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Hero Image URL</label>
              <input
                type="text"
                value={formData.heroImage}
                onChange={(e) => setFormData({ ...formData, heroImage: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 block mb-1">Proposal Overview / Hook</label>
            <textarea
              rows={2}
              value={formData.overview}
              onChange={(e) => setFormData({ ...formData, overview: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
            />
          </div>

          {/* Pricing & Margin Bar */}
          <div className="bg-slate-850 p-4 rounded-xl border border-slate-750 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Estimated Net Cost ($)</label>
              <input
                type="number"
                min="0"
                value={formData.totalCostEstimate}
                onChange={(e) => {
                  const net = Number(e.target.value);
                  const sell = formData.recommendedSellingPrice;
                  const margin = sell > 0 ? ((sell - net) / sell) * 100 : 0;
                  setFormData({
                    ...formData,
                    totalCostEstimate: net,
                    targetMarginPercent: Number(margin.toFixed(1)),
                  });
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-amber-300 font-mono text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Recommended Selling Price ($)</label>
              <input
                type="number"
                min="0"
                value={formData.recommendedSellingPrice}
                onChange={(e) => {
                  const sell = Number(e.target.value);
                  const net = formData.totalCostEstimate;
                  const margin = sell > 0 ? ((sell - net) / sell) * 100 : 0;
                  setFormData({
                    ...formData,
                    recommendedSellingPrice: sell,
                    targetMarginPercent: Number(margin.toFixed(1)),
                  });
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-emerald-300 font-mono text-xs font-bold"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Gross Margin Yield</label>
              <div className="px-3 py-2 bg-slate-900 border border-slate-750 rounded-lg text-xs font-mono text-indigo-400 font-bold">
                {formData.targetMarginPercent}% (${formData.recommendedSellingPrice - formData.totalCostEstimate} profit)
              </div>
            </div>
          </div>

          {/* Days Builder */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Day-by-Day Journey Builder ({formData.days.length} Days)
              </span>
              <button
                type="button"
                onClick={handleAddDay}
                className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs font-semibold flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Day</span>
              </button>
            </div>

            <div className="space-y-4">
              {formData.days.map((day, dIdx) => (
                <div key={day.dayNumber} className="bg-slate-850 p-4 rounded-xl border border-slate-750 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="w-6 h-6 rounded bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">
                        {day.dayNumber}
                      </span>
                      <input
                        type="text"
                        value={day.title}
                        onChange={(e) => {
                          const updated = [...formData.days];
                          updated[dIdx].title = e.target.value;
                          setFormData({ ...formData, days: updated });
                        }}
                        className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs text-white font-semibold"
                        placeholder="Day Title"
                      />
                      <input
                        type="date"
                        value={day.date}
                        onChange={(e) => {
                          const updated = [...formData.days];
                          updated[dIdx].date = e.target.value;
                          setFormData({ ...formData, days: updated });
                        }}
                        className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-slate-300"
                      />
                    </div>

                    <div className="flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => handleAddItem(dIdx, 'flight')}
                        className="px-2 py-1 bg-sky-950 hover:bg-sky-900 text-sky-300 border border-sky-800 rounded text-[11px]"
                      >
                        + Flight
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddItem(dIdx, 'hotel')}
                        className="px-2 py-1 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 rounded text-[11px]"
                      >
                        + Hotel
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddItem(dIdx, 'transfer')}
                        className="px-2 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 rounded text-[11px]"
                      >
                        + Transfer
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddItem(dIdx, 'activity')}
                        className="px-2 py-1 bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800 rounded text-[11px]"
                      >
                        + Activity
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddItem(dIdx, 'meeting')}
                        className="px-2 py-1 bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 rounded text-[11px]"
                      >
                        + Meeting
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveDay(dIdx)}
                        className="p-1.5 text-slate-500 hover:text-rose-400 ml-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Day Items */}
                  <div className="space-y-2 pl-4 border-l-2 border-slate-750">
                    {day.items.map((item, iIdx) => (
                      <div key={item.id} className="p-3 bg-slate-900 rounded-lg border border-slate-750 grid grid-cols-1 md:grid-cols-6 gap-2 items-center">
                        <div className="w-20">
                          <input
                            type="text"
                            value={item.time}
                            onChange={(e) => {
                              const updated = [...formData.days];
                              updated[dIdx].items[iIdx].time = e.target.value;
                              setFormData({ ...formData, days: updated });
                            }}
                            className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-indigo-300 font-mono"
                            placeholder="09:00"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <input
                            type="text"
                            value={item.title}
                            onChange={(e) => {
                              const updated = [...formData.days];
                              updated[dIdx].items[iIdx].title = e.target.value;
                              setFormData({ ...formData, days: updated });
                            }}
                            className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                            placeholder="Title / Service"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) => {
                              const updated = [...formData.days];
                              updated[dIdx].items[iIdx].description = e.target.value;
                              setFormData({ ...formData, days: updated });
                            }}
                            className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-slate-300"
                            placeholder="Description"
                          />
                        </div>
                        <div className="flex items-center justify-end space-x-1">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(dIdx, iIdx)}
                            className="p-1 text-slate-500 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* STANDARD BACK-OFFICE VIEW */
        <div className="bg-slate-900 border border-slate-750 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-750 pb-6">
            <div className="flex items-center space-x-4">
              <img
                src={activeItinerary.heroImage}
                alt={activeItinerary.title}
                className="w-20 h-20 rounded-xl object-cover border border-slate-700"
              />
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-xl font-bold text-white tracking-tight">{activeItinerary.title}</h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    {activeItinerary.tripType}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {activeItinerary.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Client: <strong className="text-slate-200">{activeItinerary.clientName}</strong> • Destination: <strong className="text-slate-200">{activeItinerary.destination}</strong>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Dates: {formatDate(activeItinerary.startDate)} – {formatDate(activeItinerary.endDate)} ({activeItinerary.days.length} Days)
                </p>
              </div>
            </div>

            {/* Financial margin metric card */}
            <div className="p-4 bg-slate-850 rounded-xl border border-slate-750 flex items-center space-x-6">
              <div>
                <span className="text-xs text-slate-400 block">Estimated Net Cost</span>
                <span className="text-base font-bold font-mono text-amber-400">
                  {formatUSD(activeItinerary.totalCostEstimate)}
                </span>
              </div>
              <div className="h-8 w-px bg-slate-750" />
              <div>
                <span className="text-xs text-slate-400 block">Selling Price</span>
                <span className="text-lg font-bold font-mono text-emerald-400">
                  {formatUSD(activeItinerary.recommendedSellingPrice)}
                </span>
              </div>
              <div className="h-8 w-px bg-slate-750" />
              <div>
                <span className="text-xs text-slate-400 block">Target Margin</span>
                <span className="text-base font-bold font-mono text-indigo-400">
                  {activeItinerary.targetMarginPercent}%
                </span>
              </div>
            </div>
          </div>

          {/* Day list preview */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Itinerary Segments & Program Flow
            </h3>
            {activeItinerary.days.map((day) => (
              <div key={day.dayNumber} className="p-4 bg-slate-850 rounded-xl border border-slate-750/80">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-600/30 text-indigo-300 font-bold text-xs font-mono">
                      DAY {day.dayNumber}
                    </span>
                    <h4 className="font-semibold text-white text-sm">{day.title}</h4>
                  </div>
                  <span className="text-xs text-slate-400 font-medium">{formatDate(day.date)}</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">{day.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {day.items.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 bg-slate-900/60 rounded-lg border border-slate-750 flex items-center space-x-3 text-xs"
                    >
                      <div className="p-1.5 bg-slate-800 rounded">
                        {getItemIcon(item.type)}
                      </div>
                      <div className="truncate flex-1">
                        <span className="font-semibold text-slate-200">{item.time} - {item.title}</span>
                        <p className="text-[11px] text-slate-500 truncate">{item.description}</p>
                      </div>
                      {item.badge && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">
                          {item.badge}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
