import React from 'react';
import {
  LayoutDashboard,
  CalendarDays,
  FileSpreadsheet,
  Building2,
  DollarSign,
  Plus,
  Briefcase,
  Search,
  ShieldCheck,
  Plane,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenCreateBooking: () => void;
  bookingCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenCreateBooking,
  bookingCount,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Operations & KPIs', icon: LayoutDashboard },
    { id: 'bookings', label: 'Bookings & PNRs', icon: Plane, badge: bookingCount },
    { id: 'itineraries', label: 'Itinerary Builder', icon: CalendarDays },
    { id: 'commissions', label: 'Commissions & Finance', icon: DollarSign },
    { id: 'suppliers', label: 'Suppliers & Contracts', icon: Building2 },
    { id: 'corporate', label: 'Corporate Accounts & Policy', icon: Briefcase },
  ];

  return (
    <header className="bg-slate-900/95 backdrop-blur-md border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white font-extrabold text-xl shadow-lg shadow-indigo-600/30">
              VO
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-black tracking-tight text-white">
                  VOYAGE<span className="text-indigo-500">OPS</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-indigo-400 border border-slate-700">
                  Back-Office ERP
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Corporate & Leisure Travel Operations</p>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onOpenCreateBooking}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-md shadow-indigo-600/25 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Create PNR Booking</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center space-x-1 overflow-x-auto py-2 border-t border-slate-800/80 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span
                    className={`ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
