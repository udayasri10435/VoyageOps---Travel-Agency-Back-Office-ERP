import React from 'react';
import { Booking, BookingSegment } from '../types';
import { formatDate } from '../utils/formatters';
import { Printer, X, Tag, Calendar, MapPin, CheckCircle, ShieldCheck } from 'lucide-react';

interface VoucherModalProps {
  booking: Booking;
  segment?: BookingSegment;
  onClose: () => void;
}

export const VoucherModal: React.FC<VoucherModalProps> = ({ booking, segment, onClose }) => {
  const activeSegment = segment || booking.segments[0];

  const handlePrint = () => {
    window.print();
  };

  const voucherCode = `VOUCH-${booking.pnrCode}-${activeSegment ? activeSegment.confirmationRef : 'ALL'}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Controls */}
        <div className="print:hidden flex items-center justify-between px-6 py-4 bg-slate-800/80 border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Tag className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-semibold text-white">Agency Service Confirmation Voucher</h3>
              <p className="text-xs text-slate-400">PNR: {booking.pnrCode} • {activeSegment?.supplierName}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium rounded-lg transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save Voucher</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Voucher */}
        <div className="p-8 bg-white text-slate-900 print:p-0 print:m-0" id="printable-voucher">
          {/* Header */}
          <div className="flex justify-between items-center border-b-2 border-emerald-600 pb-6 mb-6">
            <div>
              <div className="text-xl font-black text-slate-900 tracking-tight">
                VOYAGE<span className="text-emerald-600">OPS</span> TRAVEL SERVICES
              </div>
              <p className="text-xs text-slate-500">Official Confirmation & Exchange Voucher</p>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded uppercase">
                Confirmed & Guaranteed
              </span>
              <p className="text-xs font-mono font-bold text-slate-700 mt-1">{voucherCode}</p>
            </div>
          </div>

          {/* Supplier & Service Details */}
          <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Supplier / Provider</span>
                <h2 className="text-lg font-bold text-slate-900">{activeSegment?.supplierName}</h2>
                <p className="text-xs text-slate-600 font-mono mt-0.5">Supplier Confirmation: {activeSegment?.confirmationRef}</p>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Booking / PNR Reference</span>
                <p className="text-base font-bold font-mono text-emerald-700">{booking.pnrCode}</p>
                <p className="text-xs text-slate-500">File: {booking.bookingRef}</p>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Service Title</span>
              <h3 className="text-base font-semibold text-slate-800">{activeSegment?.title}</h3>
              <p className="text-sm text-slate-600 mt-1">{activeSegment?.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-200 text-sm">
              <div className="flex items-start space-x-2">
                <Calendar className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="text-xs font-medium text-slate-500">Valid From:</div>
                  <div className="font-semibold text-slate-800">{formatDate(activeSegment?.startDateTime)}</div>
                </div>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="text-xs font-medium text-slate-500">Service Location:</div>
                  <div className="font-semibold text-slate-800">{activeSegment?.destination || booking.primaryDestination}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Passenger Names */}
          <div className="mb-6">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Guest / Passenger Manifest</h4>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold">
                  <tr>
                    <th className="py-2 px-3">Passenger Name</th>
                    <th className="py-2 px-3">Passport / ID</th>
                    <th className="py-2 px-3">Nationality</th>
                    <th className="py-2 px-3">Special Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {booking.passengers.map((p, idx) => (
                    <tr key={p.id || idx}>
                      <td className="py-2.5 px-3 font-semibold">{p.title} {p.firstName} {p.lastName}</td>
                      <td className="py-2.5 px-3 font-mono">{p.passportNumber || 'ON FILE'}</td>
                      <td className="py-2.5 px-3">{p.nationality}</td>
                      <td className="py-2.5 px-3">{p.specialRequests || 'None'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Supplier Instructions & Barcode Simulation */}
          <div className="p-4 bg-emerald-50/50 rounded-lg border border-emerald-200 text-xs text-slate-600 flex justify-between items-center">
            <div>
              <p className="font-bold text-slate-800">Instructions to Service Provider:</p>
              <p>Please render services as detailed above to the voucher bearer. Bill VoyageOps Back-Office in accordance with agency contract terms. Direct incidental charges must be collected from guests.</p>
            </div>
            <div className="text-center pl-4 border-l border-emerald-200 flex-shrink-0">
              <div className="font-mono text-xs tracking-widest text-slate-400">||||| | |||| ||| ||||</div>
              <span className="text-[10px] text-slate-500 font-mono">AUTH-{booking.pnrCode}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
