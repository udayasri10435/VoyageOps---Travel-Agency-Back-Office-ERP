import React, { useState } from 'react';
import { CommissionRecord, Supplier } from '../types';
import { formatUSD, formatDate } from '../utils/formatters';
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  CheckCircle2,
  Clock,
  UserCheck,
  Building,
  ArrowUpRight,
  Filter,
  CheckSquare,
  Square,
} from 'lucide-react';

interface CommissionsViewProps {
  commissions: CommissionRecord[];
  suppliers: Supplier[];
  onUpdateCommissionStatus: (id: string, status: 'accrued' | 'approved' | 'paid') => void;
  onBatchSettle: (ids: string[]) => void;
  onSupplierPay: (supplierId: string, amount: number) => void;
}

export const CommissionsView: React.FC<CommissionsViewProps> = ({
  commissions,
  suppliers,
  onUpdateCommissionStatus,
  onBatchSettle,
  onSupplierPay,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'accrued' | 'approved' | 'paid'>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [payingSupplier, setPayingSupplier] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);

  // Financial aggregates
  const totalCommissionEarned = commissions.reduce((s, c) => s + c.totalCommissionEarned, 0);
  const totalAgentPayouts = commissions.reduce((s, c) => s + c.agentPayout, 0);
  const totalAgencyRetained = commissions.reduce((s, c) => s + c.agencyRetained, 0);
  const totalSupplierPayables = suppliers.reduce((s, sup) => s + sup.balancePayable, 0);

  const filteredCommissions = commissions.filter(
    (c) => filterStatus === 'all' || c.payoutStatus === filterStatus
  );

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedIds.length === filteredCommissions.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredCommissions.map((c) => c.id));
    }
  };

  const handleBatchApprove = () => {
    selectedIds.forEach((id) => onUpdateCommissionStatus(id, 'approved'));
    setSelectedIds([]);
  };

  const handleBatchPay = () => {
    onBatchSettle(selectedIds);
    setSelectedIds([]);
  };

  const handleOpenPaySupplier = (sup: Supplier) => {
    setPayingSupplier(sup);
    setPayAmount(sup.balancePayable);
  };

  const handleConfirmSupplierPayment = () => {
    if (payingSupplier && payAmount > 0) {
      onSupplierPay(payingSupplier.id, payAmount);
      setPayingSupplier(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total Commission Yield
            </span>
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-white mt-3">{formatUSD(totalCommissionEarned)}</p>
          <p className="text-xs text-slate-500 mt-1">Across all confirmed & completed PNRs</p>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Agency Retained Profit
            </span>
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400 mt-3">{formatUSD(totalAgencyRetained)}</p>
          <p className="text-xs text-slate-500 mt-1">Agency net share after agent splits</p>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Agent Split Payouts
            </span>
            <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-sky-400 mt-3">{formatUSD(totalAgentPayouts)}</p>
          <p className="text-xs text-slate-500 mt-1">Due / paid to travel advisors</p>
        </div>

        <div className="p-5 bg-slate-850 rounded-xl border border-slate-750">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Outstanding Supplier Payables
            </span>
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold font-mono text-amber-400 mt-3">{formatUSD(totalSupplierPayables)}</p>
          <p className="text-xs text-slate-500 mt-1">Airline BSP/ARC, Bedbanks & DMCs</p>
        </div>
      </div>

      {/* Commission Ledger Table */}
      <div className="bg-slate-850 rounded-xl border border-slate-750 overflow-hidden">
        {/* Table Header Controls */}
        <div className="p-5 border-b border-slate-750 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Agent Commission Ledger & Settlement</h3>
            <p className="text-xs text-slate-400">Track GDS overrides, advisor commission splits, and settlement batches</p>
          </div>

          <div className="flex items-center space-x-3">
            {/* Filter by status */}
            <div className="flex items-center bg-slate-900 rounded-lg p-1 border border-slate-750 text-xs">
              {(['all', 'accrued', 'approved', 'paid'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-3 py-1 rounded font-medium capitalize transition-all ${
                    filterStatus === st
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            {/* Batch Action Buttons */}
            {selectedIds.length > 0 && (
              <div className="flex items-center space-x-2 animate-fadeIn">
                <button
                  onClick={handleBatchApprove}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold transition-colors"
                >
                  Approve Selected ({selectedIds.length})
                </button>
                <button
                  onClick={handleBatchPay}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors"
                >
                  Mark Paid ({selectedIds.length})
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Ledger Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/60 text-slate-400 uppercase font-semibold border-b border-slate-750">
              <tr>
                <th className="py-3 px-4 w-10">
                  <button onClick={selectAll} className="text-slate-400 hover:text-white">
                    {selectedIds.length === filteredCommissions.length && filteredCommissions.length > 0 ? (
                      <CheckSquare className="w-4 h-4 text-indigo-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3 px-4">Booking / PNR</th>
                <th className="py-3 px-4">Advisor / Agent</th>
                <th className="py-3 px-4">Suppliers / Products</th>
                <th className="py-3 px-4 text-right">Gross Booking</th>
                <th className="py-3 px-4 text-right">Total Comm.</th>
                <th className="py-3 px-4 text-right">Agent Payout</th>
                <th className="py-3 px-4 text-right">Agency Net</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-750/70">
              {filteredCommissions.map((comm) => (
                <tr key={comm.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <button onClick={() => toggleSelect(comm.id)}>
                      {selectedIds.includes(comm.id) ? (
                        <CheckSquare className="w-4 h-4 text-indigo-400" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-500" />
                      )}
                    </button>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{comm.bookingRef}</div>
                    <div className="font-mono text-indigo-400 text-[11px]">{comm.pnrCode}</div>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-200">
                    {comm.agentName}
                    <div className="text-[11px] text-slate-500">Split: {comm.agentSplitRate}%</div>
                  </td>
                  <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                    {comm.supplierName}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-300">
                    {formatUSD(comm.grossAmount)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                    {formatUSD(comm.totalCommissionEarned)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-sky-400 font-semibold">
                    {formatUSD(comm.agentPayout)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-indigo-300 font-semibold">
                    {formatUSD(comm.agencyRetained)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${
                        comm.payoutStatus === 'paid'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : comm.payoutStatus === 'approved'
                          ? 'bg-sky-500/20 text-sky-300 border-sky-500/30'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      }`}
                    >
                      {comm.payoutStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end space-x-1">
                      {comm.payoutStatus === 'accrued' && (
                        <button
                          onClick={() => onUpdateCommissionStatus(comm.id, 'approved')}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded text-[11px] border border-slate-700"
                        >
                          Approve
                        </button>
                      )}
                      {comm.payoutStatus === 'approved' && (
                        <button
                          onClick={() => onUpdateCommissionStatus(comm.id, 'paid')}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded text-[11px] border border-slate-700"
                        >
                          Mark Paid
                        </button>
                      )}
                      {comm.payoutStatus === 'paid' && (
                        <span className="text-[11px] text-slate-500 italic">Settled</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Supplier Payables Aging & Disbursement Section */}
      <div className="bg-slate-850 rounded-xl border border-slate-750 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Supplier Payables Schedule</h3>
            <p className="text-xs text-slate-400">Direct contract balances, GDS billing cycles, and net payment terms</p>
          </div>
          <span className="text-xs text-amber-400 font-mono font-bold">
            Total Due: {formatUSD(totalSupplierPayables)}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {suppliers
            .filter((s) => s.balancePayable > 0)
            .map((sup) => (
              <div key={sup.id} className="p-4 bg-slate-900 rounded-xl border border-slate-750 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{sup.name}</span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {sup.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 capitalize">
                    {sup.category.replace('_', ' ')} • Terms: {sup.paymentTerms.replace('_', ' ').toUpperCase()}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500 block uppercase">Balance Payable</span>
                    <span className="font-mono text-amber-400 font-bold text-base">
                      {formatUSD(sup.balancePayable)}
                    </span>
                  </div>
                  <button
                    onClick={() => handleOpenPaySupplier(sup)}
                    className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs font-semibold transition-colors"
                  >
                    Disburse
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Modal: Pay Supplier */}
      {payingSupplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Record Supplier Disbursement</h3>
            <p className="text-xs text-slate-400">
              Disburse payable balance to <strong>{payingSupplier.name}</strong> via IATA BSP or direct corporate wire.
            </p>

            <div className="p-3 bg-slate-850 rounded-lg border border-slate-750 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Current Balance:</span>
                <span className="font-mono text-amber-400 font-bold">{formatUSD(payingSupplier.balancePayable)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Credit Limit:</span>
                <span className="font-mono text-slate-300">{formatUSD(payingSupplier.creditLimit)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Terms:</span>
                <span className="uppercase text-slate-300">{payingSupplier.paymentTerms}</span>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-400 block mb-1">Disbursement Amount ($)</label>
              <input
                type="number"
                min="1"
                max={payingSupplier.balancePayable}
                value={payAmount}
                onChange={(e) => setPayAmount(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono text-sm"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setPayingSupplier(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSupplierPayment}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm"
              >
                Confirm Settlement
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
