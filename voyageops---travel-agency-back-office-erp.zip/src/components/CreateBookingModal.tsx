import React, { useState } from 'react';
import { Booking, BookingSegment, CorporateAccount, Passenger, SegmentType, Supplier } from '../types';
import { generateBookingRef, generatePNR, formatUSD } from '../utils/formatters';
import { X, Plus, Trash2, ShieldCheck, AlertTriangle, CheckCircle, Calculator, Building, UserCheck } from 'lucide-react';

interface CreateBookingModalProps {
  suppliers: Supplier[];
  corporateAccounts: CorporateAccount[];
  onSave: (booking: Booking) => void;
  onClose: () => void;
}

export const CreateBookingModal: React.FC<CreateBookingModalProps> = ({
  suppliers,
  corporateAccounts,
  onSave,
  onClose,
}) => {
  const [bookingType, setBookingType] = useState<'corporate' | 'leisure'>('corporate');
  const [title, setTitle] = useState('');
  const [selectedCorpId, setSelectedCorpId] = useState(corporateAccounts[0]?.id || '');
  const [clientName, setClientName] = useState(corporateAccounts[0]?.companyName || '');
  const [clientEmail, setClientEmail] = useState(corporateAccounts[0]?.billingEmail || '');
  const [clientPhone, setClientPhone] = useState('+1 415 555 0100');
  const [costCenter, setCostCenter] = useState('CC-EXEC-101');
  const [pnrCode, setPnrCode] = useState(generatePNR());
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('2026-10-20');
  const [endDate, setEndDate] = useState('2026-10-25');
  const [agentName, setAgentName] = useState('Marcus Vance');
  const [agentSplitRate, setAgentSplitRate] = useState(40);
  const [internalNotes, setInternalNotes] = useState('');

  // Passengers
  const [passengers, setPassengers] = useState<Passenger[]>([
    {
      id: 'pax-' + Date.now(),
      title: 'Mr.',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      passportNumber: '',
      passportExpiry: '2029-12-31',
      nationality: 'United States',
      frequentFlyer: '',
      specialRequests: '',
    },
  ]);

  // Segments
  const [segments, setSegments] = useState<BookingSegment[]>([
    {
      id: 'seg-' + Date.now(),
      type: 'flight',
      supplierId: suppliers[0]?.id || 'sup-singapore',
      supplierName: suppliers[0]?.name || 'Singapore Airlines',
      confirmationRef: 'SQ-' + Math.floor(1000 + Math.random() * 9000),
      title: 'Outbound Flight Segment',
      description: 'Business Class confirmed itinerary',
      startDateTime: '2026-10-20T08:00:00',
      endDateTime: '2026-10-20T16:30:00',
      origin: 'JFK',
      destination: 'LHR',
      netCost: 3500,
      grossAmount: 4000,
      commissionRate: 6.0,
      commissionAmount: 240,
      currency: 'USD',
      status: 'confirmed',
    },
  ]);

  const handleCorpChange = (corpId: string) => {
    setSelectedCorpId(corpId);
    const corp = corporateAccounts.find((c) => c.id === corpId);
    if (corp) {
      setClientName(corp.companyName);
      setClientEmail(corp.billingEmail);
    }
  };

  // Add / remove passenger
  const addPassenger = () => {
    setPassengers([
      ...passengers,
      {
        id: 'pax-' + Date.now(),
        title: 'Ms.',
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        passportNumber: '',
        passportExpiry: '2030-01-01',
        nationality: 'United States',
      },
    ]);
  };

  const removePassenger = (index: number) => {
    if (passengers.length > 1) {
      setPassengers(passengers.filter((_, i) => i !== index));
    }
  };

  const updatePassenger = (index: number, field: keyof Passenger, value: string) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  // Add / remove segment
  const addSegment = (type: SegmentType) => {
    const defaultSup = suppliers.find((s) =>
      type === 'flight' ? s.category === 'airline' :
      type === 'hotel' ? s.category === 'hotel_chain' :
      s.category === 'dmc'
    ) || suppliers[0];

    const newSeg: BookingSegment = {
      id: 'seg-' + Date.now() + Math.random(),
      type,
      supplierId: defaultSup.id,
      supplierName: defaultSup.name,
      confirmationRef: defaultSup.code + '-' + Math.floor(1000 + Math.random() * 9000),
      title: `${type.toUpperCase()} Segment`,
      description: `Confirmed reservation with ${defaultSup.name}`,
      startDateTime: startDate + 'T12:00:00',
      endDateTime: endDate + 'T11:00:00',
      netCost: 1000,
      grossAmount: 1200,
      commissionRate: defaultSup.defaultCommissionRate || 8.0,
      commissionAmount: (1200 * (defaultSup.defaultCommissionRate || 8.0)) / 100,
      currency: 'USD',
      status: 'confirmed',
    };
    setSegments([...segments, newSeg]);
  };

  const updateSegment = (index: number, field: keyof BookingSegment, value: any) => {
    const updated = [...segments];
    const seg = { ...updated[index], [field]: value };

    // Auto recalculate commission amount if gross or rate changes
    if (field === 'grossAmount' || field === 'commissionRate') {
      const gross = field === 'grossAmount' ? Number(value) : seg.grossAmount;
      const rate = field === 'commissionRate' ? Number(value) : seg.commissionRate;
      seg.commissionAmount = (gross * rate) / 100;
    }
    if (field === 'supplierId') {
      const sup = suppliers.find((s) => s.id === value);
      if (sup) {
        seg.supplierName = sup.name;
        seg.commissionRate = sup.defaultCommissionRate;
        seg.commissionAmount = (seg.grossAmount * sup.defaultCommissionRate) / 100;
      }
    }
    updated[index] = seg;
    setSegments(updated);
  };

  const removeSegment = (index: number) => {
    if (segments.length > 1) {
      setSegments(segments.filter((_, i) => i !== index));
    }
  };

  // Financial calculations
  const totalNet = segments.reduce((sum, s) => sum + (Number(s.netCost) || 0), 0);
  const totalGross = segments.reduce((sum, s) => sum + (Number(s.grossAmount) || 0), 0);
  const totalCommission = segments.reduce((sum, s) => sum + (Number(s.commissionAmount) || 0), 0);
  const markupAmount = Math.max(0, totalGross - totalNet);
  const markupPercentage = totalNet > 0 ? (markupAmount / totalNet) * 100 : 0;
  const agentCommissionShare = (totalCommission * agentSplitRate) / 100;
  const agencyNetProfit = totalGross - totalNet + (totalCommission - agentCommissionShare);

  // Corporate travel policy check
  const activeCorp = corporateAccounts.find((c) => c.id === selectedCorpId);
  let policyCompliance: 'compliant' | 'exception_approved' | 'out_of_policy' = 'compliant';
  let policyWarning = '';

  if (bookingType === 'corporate' && activeCorp) {
    if (totalGross > activeCorp.travelPolicy.requireApprovalAboveUSD) {
      policyCompliance = 'exception_approved';
      policyWarning = `Total gross (${formatUSD(totalGross)}) exceeds company pre-approval cap (${formatUSD(activeCorp.travelPolicy.requireApprovalAboveUSD)}). Auto exception flagging applied.`;
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Ensure passengers have valid names if empty
    const validatedPassengers = passengers.map((p, idx) => ({
      ...p,
      firstName: p.firstName.trim() || `Traveler`,
      lastName: p.lastName.trim() || `${idx + 1}`,
      email: p.email.trim() || clientEmail,
    }));

    const newBooking: Booking = {
      id: 'bk-' + Date.now(),
      bookingRef: generateBookingRef(),
      pnrCode: pnrCode.toUpperCase().trim() || generatePNR(),
      type: bookingType,
      title: title || `${destination || 'Global'} Itinerary - ${clientName}`,
      clientName,
      clientEmail,
      clientPhone,
      corporateId: bookingType === 'corporate' ? selectedCorpId : undefined,
      corporateCostCenter: bookingType === 'corporate' ? costCenter : undefined,
      travelPolicyCompliance: policyCompliance,
      policyNotes: policyWarning || 'Policy validated against current rules.',
      status: 'confirmed',
      bookingDate: new Date().toISOString().split('T')[0],
      travelStartDate: startDate,
      travelEndDate: endDate,
      primaryDestination: destination || 'Worldwide Destination',
      passengers: validatedPassengers,
      segments,
      financials: {
        totalNetCost: totalNet,
        totalGrossAmount: totalGross,
        markupAmount,
        markupPercentage: Number(markupPercentage.toFixed(2)),
        totalCommissionEarned: totalCommission,
        agentSplitRate,
        agentCommissionShare,
        agencyNetProfit,
        invoiceStatus: 'unbilled',
        supplierPaymentStatus: 'pending',
        currency: 'USD',
      },
      agentId: 'agt-current',
      agentName,
      internalNotes,
      timeline: [
        {
          id: 'ev-' + Date.now(),
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          actor: agentName,
          action: 'New Booking File Created',
          note: `Created as ${bookingType} file. PNR: ${pnrCode}`,
        },
      ],
    };

    onSave(newBooking);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-750 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-850 border-b border-slate-750 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold">
              +
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Create New Travel Booking (PNR File)</h2>
              <p className="text-xs text-slate-400">Integrated corporate policy verification & multi-segment accounting</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-200 text-sm">
          {/* Booking Type & Client Mode */}
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Booking Category</span>
              <div className="inline-flex p-1 bg-slate-900 rounded-lg border border-slate-700">
                <button
                  type="button"
                  onClick={() => {
                    setBookingType('corporate');
                    if (corporateAccounts.length > 0) {
                      setClientName(corporateAccounts[0].companyName);
                      setClientEmail(corporateAccounts[0].billingEmail);
                    }
                  }}
                  className={`px-4 py-1.5 rounded-md text-xs font-semibold transition-all ${
                    bookingType === 'corporate'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Corporate Account
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setBookingType('leisure');
                    setClientName('Mr. & Mrs. Traveler');
                    setClientEmail('traveler@personal.com');
                  }}
                  className={`px-4 py-1.5 rounded-md text-xs font-semibold transition-all ${
                    bookingType === 'leisure'
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Leisure / FIT Traveler
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {bookingType === 'corporate' ? (
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Corporate Client *</label>
                  <select
                    value={selectedCorpId}
                    onChange={(e) => handleCorpChange(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:ring-2 focus:ring-indigo-500"
                  >
                    {corporateAccounts.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.companyName}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Client Name *</label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="e.g. Sterling Family Office"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">Billing Email *</label>
                <input
                  type="email"
                  required
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
                />
              </div>

              {bookingType === 'corporate' ? (
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Corporate Cost Center</label>
                  <input
                    type="text"
                    value={costCenter}
                    onChange={(e) => setCostCenter(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs font-mono"
                    placeholder="CC-102"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Booking Core Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-400 mb-1">Trip / Booking Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Q4 Executive Leadership Summit - London"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">GDS PNR Reference *</label>
              <div className="flex space-x-1">
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={pnrCode}
                  onChange={(e) => setPnrCode(e.target.value.toUpperCase())}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs font-mono font-bold uppercase tracking-wider"
                />
                <button
                  type="button"
                  onClick={() => setPnrCode(generatePNR())}
                  title="Generate new PNR"
                  className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-[11px] text-slate-300"
                >
                  Gen
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Destination *</label>
              <input
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="e.g. London & Zurich"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Travel Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Travel End Date</label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Handling Agent</label>
              <input
                type="text"
                value={agentName}
                onChange={(e) => setAgentName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Agent Split Rate (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={agentSplitRate}
                onChange={(e) => setAgentSplitRate(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-xs font-mono"
              />
            </div>
          </div>

          {/* Passengers Section */}
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Passenger Manifest ({passengers.length})
              </span>
              <button
                type="button"
                onClick={addPassenger}
                className="flex items-center space-x-1 text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Passenger</span>
              </button>
            </div>

            <div className="space-y-3">
              {passengers.map((pax, idx) => (
                <div key={pax.id} className="p-3 bg-slate-850 rounded-lg border border-slate-750 grid grid-cols-1 md:grid-cols-6 gap-2 items-center">
                  <div className="w-16">
                    <select
                      value={pax.title}
                      onChange={(e) => updatePassenger(idx, 'title', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-xs text-white"
                    >
                      <option>Mr.</option>
                      <option>Ms.</option>
                      <option>Mrs.</option>
                      <option>Dr.</option>
                      <option>Prof.</option>
                    </select>
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="First Name *"
                      required
                      value={pax.firstName}
                      onChange={(e) => updatePassenger(idx, 'firstName', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Last Name *"
                      required
                      value={pax.lastName}
                      onChange={(e) => updatePassenger(idx, 'lastName', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Passport #"
                      value={pax.passportNumber}
                      onChange={(e) => updatePassenger(idx, 'passportNumber', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Frequent Flyer / Meal"
                      value={pax.frequentFlyer || ''}
                      onChange={(e) => updatePassenger(idx, 'frequentFlyer', e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div className="text-right flex items-center justify-end">
                    <button
                      type="button"
                      disabled={passengers.length <= 1}
                      onClick={() => removePassenger(idx)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 disabled:opacity-20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Segments Section */}
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/80 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                  Segments & Service Lines ({segments.length})
                </span>
                <span className="text-[11px] text-slate-500 ml-2">Flights, Hotels, Transfers, DMC tours</span>
              </div>
              <div className="flex space-x-1.5">
                <button
                  type="button"
                  onClick={() => addSegment('flight')}
                  className="px-2.5 py-1 bg-sky-950/80 hover:bg-sky-900 border border-sky-800 text-sky-300 rounded text-xs"
                >
                  + Flight
                </button>
                <button
                  type="button"
                  onClick={() => addSegment('hotel')}
                  className="px-2.5 py-1 bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-800 text-indigo-300 rounded text-xs"
                >
                  + Hotel
                </button>
                <button
                  type="button"
                  onClick={() => addSegment('transfer')}
                  className="px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded text-xs"
                >
                  + Transfer
                </button>
                <button
                  type="button"
                  onClick={() => addSegment('activity')}
                  className="px-2.5 py-1 bg-amber-950/80 hover:bg-amber-900 border border-amber-800 text-amber-300 rounded text-xs"
                >
                  + Activity
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {segments.map((seg, idx) => (
                <div key={seg.id} className="p-3 bg-slate-850 rounded-lg border border-slate-750 space-y-2">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-2 items-center">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase block">Segment Title</label>
                      <input
                        type="text"
                        required
                        value={seg.title}
                        onChange={(e) => updateSegment(idx, 'title', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase block">Supplier</label>
                      <select
                        value={seg.supplierId}
                        onChange={(e) => updateSegment(idx, 'supplierId', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                      >
                        {suppliers.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.code})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase block">Supplier Conf #</label>
                      <input
                        type="text"
                        value={seg.confirmationRef}
                        onChange={(e) => updateSegment(idx, 'confirmationRef', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-white"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="w-full">
                        <label className="text-[10px] text-slate-400 uppercase block">Status</label>
                        <select
                          value={seg.status}
                          onChange={(e) => updateSegment(idx, 'status', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        >
                          <option value="confirmed">Confirmed</option>
                          <option value="ticketed">Ticketed</option>
                          <option value="on_request">On Request</option>
                        </select>
                      </div>
                      <button
                        type="button"
                        disabled={segments.length <= 1}
                        onClick={() => removeSegment(idx)}
                        className="ml-2 mt-4 p-1 text-slate-500 hover:text-rose-400 disabled:opacity-20"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Financial inputs for this segment */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-2 border-t border-slate-750/70 bg-slate-900/40 p-2 rounded">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase">Net Cost ($)</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={seg.netCost}
                        onChange={(e) => updateSegment(idx, 'netCost', Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-amber-300"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase">Gross Sell ($)</label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={seg.grossAmount}
                        onChange={(e) => updateSegment(idx, 'grossAmount', Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-emerald-300"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase">Commission %</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        step="0.5"
                        value={seg.commissionRate}
                        onChange={(e) => updateSegment(idx, 'commissionRate', Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase">Comm. Earned ($)</label>
                      <div className="px-2 py-1 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-sky-400 font-semibold">
                        {formatUSD(seg.commissionAmount)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Financial Breakdown Bar */}
          <div className="p-4 bg-gradient-to-r from-slate-850 via-slate-800 to-slate-850 rounded-xl border border-indigo-500/30">
            <div className="flex items-center space-x-2 mb-3">
              <Calculator className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-300">
                Financial Margin & Commission Settlement Summary
              </span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-xs">
              <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-750">
                <span className="text-slate-400 block text-[11px]">Total Net Cost:</span>
                <span className="text-base font-bold font-mono text-amber-400">{formatUSD(totalNet)}</span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-750">
                <span className="text-slate-400 block text-[11px]">Total Gross Sell:</span>
                <span className="text-base font-bold font-mono text-emerald-400">{formatUSD(totalGross)}</span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-750">
                <span className="text-slate-400 block text-[11px]">Gross Markup:</span>
                <span className="text-base font-bold font-mono text-indigo-300">
                  {formatUSD(markupAmount)} ({markupPercentage.toFixed(1)}%)
                </span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-750">
                <span className="text-slate-400 block text-[11px]">Agent Split ({agentSplitRate}%):</span>
                <span className="text-base font-bold font-mono text-sky-400">{formatUSD(agentCommissionShare)}</span>
              </div>
              <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-750">
                <span className="text-slate-400 block text-[11px]">Agency Net Margin:</span>
                <span className="text-base font-bold font-mono text-emerald-300 font-extrabold">{formatUSD(agencyNetProfit)}</span>
              </div>
            </div>

            {policyWarning && (
              <div className="mt-3 p-2 bg-amber-500/10 border border-amber-500/30 rounded text-amber-300 text-xs flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{policyWarning}</span>
              </div>
            )}
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-850 border-t border-slate-750 flex-shrink-0">
          <div className="text-xs text-slate-400">
            Auto-generates GDS PNR, E-Ticket coupon shell, and corporate invoice voucher.
          </div>
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-indigo-600/25 transition-all flex items-center space-x-2"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Confirm & Issue Booking File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
