/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Booking,
  BookingStatus,
  CorporateAccount,
  Itinerary,
  Supplier,
  CommissionRecord,
} from './types';
import {
  initialBookings,
  initialCorporateAccounts,
  initialItineraries,
  initialSuppliers,
  initialCommissions,
} from './data/mockData';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { BookingsHub } from './components/BookingsHub';
import { ItineraryBuilder } from './components/ItineraryBuilder';
import { CommissionsView } from './components/CommissionsView';
import { SuppliersView } from './components/SuppliersView';
import { CorporateAccountsView } from './components/CorporateAccountsView';
import { BookingDetailModal } from './components/BookingDetailModal';
import { CreateBookingModal } from './components/CreateBookingModal';

export default function App() {
  // State with LocalStorage Persistence
  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const saved = localStorage.getItem('voyageops_bookings');
      return saved ? JSON.parse(saved) : initialBookings;
    } catch {
      return initialBookings;
    }
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    try {
      const saved = localStorage.getItem('voyageops_suppliers');
      return saved ? JSON.parse(saved) : initialSuppliers;
    } catch {
      return initialSuppliers;
    }
  });

  const [corporateAccounts, setCorporateAccounts] = useState<CorporateAccount[]>(() => {
    try {
      const saved = localStorage.getItem('voyageops_corporate');
      return saved ? JSON.parse(saved) : initialCorporateAccounts;
    } catch {
      return initialCorporateAccounts;
    }
  });

  const [itineraries, setItineraries] = useState<Itinerary[]>(() => {
    try {
      const saved = localStorage.getItem('voyageops_itineraries');
      return saved ? JSON.parse(saved) : initialItineraries;
    } catch {
      return initialItineraries;
    }
  });

  const [commissions, setCommissions] = useState<CommissionRecord[]>(() => {
    try {
      const saved = localStorage.getItem('voyageops_commissions');
      return saved ? JSON.parse(saved) : initialCommissions;
    } catch {
      return initialCommissions;
    }
  });

  // UI Navigation & Modals
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [showCreateBooking, setShowCreateBooking] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('voyageops_bookings', JSON.stringify(bookings));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [bookings]);

  useEffect(() => {
    try {
      localStorage.setItem('voyageops_suppliers', JSON.stringify(suppliers));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [suppliers]);

  useEffect(() => {
    try {
      localStorage.setItem('voyageops_corporate', JSON.stringify(corporateAccounts));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [corporateAccounts]);

  useEffect(() => {
    try {
      localStorage.setItem('voyageops_itineraries', JSON.stringify(itineraries));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [itineraries]);

  useEffect(() => {
    try {
      localStorage.setItem('voyageops_commissions', JSON.stringify(commissions));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [commissions]);

  // Keep selectedBooking in sync if bookings update
  useEffect(() => {
    if (selectedBooking) {
      const updated = bookings.find((b) => b.id === selectedBooking.id);
      if (updated) setSelectedBooking(updated);
    }
  }, [bookings]);

  // Booking handlers
  const handleSaveBooking = (newBooking: Booking) => {
    setBookings([newBooking, ...bookings]);

    // Also auto-generate commission record
    if (newBooking.financials.totalCommissionEarned > 0) {
      const newComm: CommissionRecord = {
        id: 'comm-' + Date.now(),
        bookingId: newBooking.id,
        bookingRef: newBooking.bookingRef,
        pnrCode: newBooking.pnrCode,
        agentId: newBooking.agentId,
        agentName: newBooking.agentName,
        supplierName: newBooking.segments.map((s) => s.supplierName).join(' / ') || 'Consolidated',
        grossAmount: newBooking.financials.totalGrossAmount,
        totalCommissionEarned: newBooking.financials.totalCommissionEarned,
        agentSplitRate: newBooking.financials.agentSplitRate,
        agentPayout: newBooking.financials.agentCommissionShare,
        agencyRetained: newBooking.financials.totalCommissionEarned - newBooking.financials.agentCommissionShare,
        payoutStatus: 'accrued',
        createdAt: new Date().toISOString().split('T')[0],
      };
      setCommissions([newComm, ...commissions]);
    }

    setShowCreateBooking(false);
    setSelectedBooking(newBooking);
  };

  const handleUpdateBookingStatus = (id: string, status: BookingStatus) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id !== id) return b;
        const newTimeline = [
          ...b.timeline,
          {
            id: 'ev-' + Date.now(),
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
            actor: 'System Operator',
            action: `Status Updated to ${status.toUpperCase()}`,
            note: `Booking file transitioned to ${status}`,
          },
        ];
        return { ...b, status, timeline: newTimeline };
      })
    );
  };

  const handleUpdateBookingFinancials = (id: string, updates: Partial<Booking['financials']>) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id !== id) return b;
        return {
          ...b,
          financials: {
            ...b.financials,
            ...updates,
          },
        };
      })
    );
  };

  // Itinerary handlers
  const handleSaveItinerary = (itin: Itinerary) => {
    setItineraries((prev) => {
      const idx = prev.findIndex((i) => i.id === itin.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = itin;
        return copy;
      }
      return [itin, ...prev];
    });
  };

  const handleConvertToBooking = (booking: Booking) => {
    handleSaveBooking(booking);
    setActiveTab('bookings');
  };

  // Supplier handlers
  const handleAddSupplier = (supplier: Supplier) => {
    setSuppliers([supplier, ...suppliers]);
  };

  const handleSupplierPay = (supplierId: string, amount: number) => {
    setSuppliers((prev) =>
      prev.map((s) => {
        if (s.id !== supplierId) return s;
        return {
          ...s,
          balancePayable: Math.max(0, s.balancePayable - amount),
        };
      })
    );
  };

  // Commission handlers
  const handleUpdateCommissionStatus = (id: string, status: 'accrued' | 'approved' | 'paid') => {
    setCommissions((prev) =>
      prev.map((c) => {
        if (c.id !== id) return c;
        return {
          ...c,
          payoutStatus: status,
          settlementDate: status === 'paid' ? new Date().toISOString().split('T')[0] : c.settlementDate,
        };
      })
    );
  };

  const handleBatchSettleCommissions = (ids: string[]) => {
    setCommissions((prev) =>
      prev.map((c) => {
        if (!ids.includes(c.id)) return c;
        return {
          ...c,
          payoutStatus: 'paid',
          settlementDate: new Date().toISOString().split('T')[0],
        };
      })
    );
  };

  // Corporate account handlers
  const handleAddCorporateAccount = (account: CorporateAccount) => {
    setCorporateAccounts([account, ...corporateAccounts]);
  };

  const handleUpdatePolicy = (id: string, policy: CorporateAccount['travelPolicy']) => {
    setCorporateAccounts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, travelPolicy: policy } : c))
    );
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenCreateBooking={() => setShowCreateBooking(true)}
        bookingCount={bookings.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            bookings={bookings}
            suppliers={suppliers}
            corporateAccounts={corporateAccounts}
            commissions={commissions}
            onSelectBooking={(b) => setSelectedBooking(b)}
            onNavigateTab={setActiveTab}
            onOpenCreateBooking={() => setShowCreateBooking(true)}
          />
        )}

        {activeTab === 'bookings' && (
          <BookingsHub
            bookings={bookings}
            onSelectBooking={(b) => setSelectedBooking(b)}
            onOpenCreateBooking={() => setShowCreateBooking(true)}
          />
        )}

        {activeTab === 'itineraries' && (
          <ItineraryBuilder
            itineraries={itineraries}
            onSaveItinerary={handleSaveItinerary}
            onConvertToBooking={handleConvertToBooking}
          />
        )}

        {activeTab === 'commissions' && (
          <CommissionsView
            commissions={commissions}
            suppliers={suppliers}
            onUpdateCommissionStatus={handleUpdateCommissionStatus}
            onBatchSettle={handleBatchSettleCommissions}
            onSupplierPay={handleSupplierPay}
          />
        )}

        {activeTab === 'suppliers' && (
          <SuppliersView suppliers={suppliers} onAddSupplier={handleAddSupplier} />
        )}

        {activeTab === 'corporate' && (
          <CorporateAccountsView
            corporateAccounts={corporateAccounts}
            onAddCorporateAccount={handleAddCorporateAccount}
            onUpdatePolicy={handleUpdatePolicy}
          />
        )}
      </main>

      {/* Modals */}
      {selectedBooking && (
        <BookingDetailModal
          booking={selectedBooking}
          onUpdateStatus={handleUpdateBookingStatus}
          onUpdateFinancials={handleUpdateBookingFinancials}
          onClose={() => setSelectedBooking(null)}
        />
      )}

      {showCreateBooking && (
        <CreateBookingModal
          suppliers={suppliers}
          corporateAccounts={corporateAccounts}
          onSave={handleSaveBooking}
          onClose={() => setShowCreateBooking(false)}
        />
      )}
    </div>
  );
}
